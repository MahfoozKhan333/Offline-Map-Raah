/*
 * Minimal slippy-map renderer (canvas). No dependencies, works fully offline.
 * Draws XYZ raster tiles, place markers, the user's GPS position and a line to a navigation target.
 */
(function (root) {
  'use strict';

  const TILE = 256;
  const MAX_LAT = 85.0511287798;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

  function project(lat, lng, zoom) {
    const s = TILE * Math.pow(2, zoom);
    const sin = Math.sin(clamp(lat, -MAX_LAT, MAX_LAT) * Math.PI / 180);
    return { x: (lng + 180) / 360 * s, y: (0.5 - Math.log((1 + sin) / (1 - sin)) / (4 * Math.PI)) * s };
  }

  function unproject(x, y, zoom) {
    const s = TILE * Math.pow(2, zoom);
    const n = Math.PI - 2 * Math.PI * y / s;
    return { lat: 180 / Math.PI * Math.atan(Math.sinh(n)), lng: x / s * 360 - 180 };
  }

  const wrapLng = (lng) => ((((lng + 180) % 360) + 360) % 360) - 180;
  const ease = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

  class SlippyMap {
    constructor(canvas, opts = {}) {
      this.canvas = canvas;
      this.ctx = canvas.getContext('2d');
      this.tileUrl = opts.tileUrl || ((z, x, y) => `/tiles/${z}/${x}/${y}`);
      this.onSelect = opts.onSelect || (() => {});
      this.onTap = opts.onTap || (() => {});
      this.tileMin = 0;
      this.tileMax = 19;
      this.hasTiles = true;
      this.minZoom = 3;
      this.maxZoom = 19;
      this.lat = 25.2048;
      this.lng = 55.2708;
      this.zoom = 11;
      this.markers = [];
      this.selected = null;
      this.me = null; // { lat, lng, acc }
      this.target = null; // { lat, lng }
      this.route = null; // [[lat, lng], ...] road route to draw
      this.cache = new Map();
      this.pointers = new Map();
      this.tap = null;
      this.dirty = false;
      this.anim = null;
      this.w = 0;
      this.h = 0;
      this.dpr = 1;
      this._bind();
      this.resize();
    }

    /* ---- configuration ---- */
    setTileRange(min, max, hasTiles) {
      this.hasTiles = !!hasTiles;
      this.tileMin = hasTiles ? min : 0;
      this.tileMax = hasTiles ? max : 19;
      this.minZoom = hasTiles ? Math.max(2, min) : 3;
      this.maxZoom = hasTiles ? Math.min(20, max + 2) : 18; // allow 2 levels of over-zoom
      this.zoom = clamp(this.zoom, this.minZoom, this.maxZoom);
      this.invalidate();
    }

    setMarkers(list) { this.markers = list; this.invalidate(); }

    /* ---- geometry ---- */
    toScreen(lat, lng) {
      const p = project(lat, lng, this.zoom);
      const c = project(this.lat, this.lng, this.zoom);
      return { x: this.w / 2 + (p.x - c.x), y: this.h / 2 + (p.y - c.y) };
    }

    fromScreen(x, y) {
      const c = project(this.lat, this.lng, this.zoom);
      return unproject(c.x + (x - this.w / 2), c.y + (y - this.h / 2), this.zoom);
    }

    getBounds() {
      const tl = this.fromScreen(0, 0);
      const br = this.fromScreen(this.w, this.h);
      return { w: tl.lng, n: tl.lat, e: br.lng, s: br.lat };
    }

    resize() {
      const r = this.canvas.getBoundingClientRect();
      this.dpr = Math.min(window.devicePixelRatio || 1, 3);
      this.w = Math.max(1, Math.round(r.width));
      this.h = Math.max(1, Math.round(r.height));
      this.canvas.width = Math.round(this.w * this.dpr);
      this.canvas.height = Math.round(this.h * this.dpr);
      this.invalidate();
    }

    /* ---- movement ---- */
    panBy(dx, dy) {
      const c = project(this.lat, this.lng, this.zoom);
      const u = unproject(c.x - dx, c.y - dy, this.zoom);
      this.lat = clamp(u.lat, -MAX_LAT, MAX_LAT);
      this.lng = wrapLng(u.lng);
      this.invalidate();
    }

    zoomAt(x, y, z) {
      z = clamp(z, this.minZoom, this.maxZoom);
      if (z === this.zoom) return;
      const g = this.fromScreen(x, y);
      this.zoom = z;
      const s = this.toScreen(g.lat, g.lng);
      this.panBy(x - s.x, y - s.y);
    }

    zoomBy(d) { this.zoomAt(this.w / 2, this.h / 2, this.zoom + d); }

    setView(lat, lng, zoom) {
      this.anim = null;
      this.lat = clamp(lat, -MAX_LAT, MAX_LAT);
      this.lng = wrapLng(lng);
      if (zoom != null) this.zoom = clamp(zoom, this.minZoom, this.maxZoom);
      this.invalidate();
    }

    // zoom/centre so that a list of [lat, lng] points fits on screen
    fitPoints(points, pad = 70, maxZoom = 17) {
      if (!points.length) return;
      let n = -90, s = 90, e = -180, w = 180;
      for (const p of points) { n = Math.max(n, p[0]); s = Math.min(s, p[0]); e = Math.max(e, p[1]); w = Math.min(w, p[1]); }
      const aw = Math.max(40, this.w - pad * 2), ah = Math.max(40, this.h - pad * 2 - (this.w < 700 ? 150 : 0));
      let z = Math.min(maxZoom, this.maxZoom);
      for (; z > this.minZoom; z -= 0.25) {
        const a = project(n, w, z), b = project(s, e, z);
        if (b.x - a.x <= aw && b.y - a.y <= ah) break;
      }
      this.flyTo((n + s) / 2, (w + e) / 2, z);
    }

    flyTo(lat, lng, zoom, ms = 600) {
      const to = { lat, lng, zoom: clamp(zoom == null ? this.zoom : zoom, this.minZoom, this.maxZoom) };
      const from = { lat: this.lat, lng: this.lng, zoom: this.zoom };
      let dLng = to.lng - from.lng;
      if (dLng > 180) dLng -= 360;
      if (dLng < -180) dLng += 360;
      this.anim = { from, to, dLng, t0: performance.now(), ms };
      requestAnimationFrame((t) => this._tick(t));
    }

    _tick(now) {
      const a = this.anim;
      if (!a) return;
      const t = clamp((now - a.t0) / a.ms, 0, 1);
      const e = ease(t);
      this.lat = a.from.lat + (a.to.lat - a.from.lat) * e;
      this.lng = wrapLng(a.from.lng + a.dLng * e);
      this.zoom = a.from.zoom + (a.to.zoom - a.from.zoom) * e;
      this.invalidate();
      if (t < 1) requestAnimationFrame((n) => this._tick(n)); else this.anim = null;
    }

    /* ---- input ---- */
    _pos(e) {
      const r = this.canvas.getBoundingClientRect();
      return { x: e.clientX - r.left, y: e.clientY - r.top };
    }

    _bind() {
      const c = this.canvas;

      c.addEventListener('pointerdown', (e) => {
        c.setPointerCapture(e.pointerId);
        const p = this._pos(e);
        this.pointers.set(e.pointerId, p);
        this.anim = null;
        if (this.pointers.size === 1) this.tap = { x: p.x, y: p.y, t: Date.now(), moved: false };
        else if (this.tap) this.tap.moved = true;
        c.classList.add('grabbing');
      });

      c.addEventListener('pointermove', (e) => {
        const prev = this.pointers.get(e.pointerId);
        if (!prev) return;
        const n = this._pos(e);
        if (this.pointers.size === 1) {
          if (this.tap && Math.hypot(n.x - this.tap.x, n.y - this.tap.y) > 6) this.tap.moved = true;
          this.panBy(n.x - prev.x, n.y - prev.y);
          prev.x = n.x; prev.y = n.y;
        } else if (this.pointers.size === 2) {
          const [a, b] = [...this.pointers.values()];
          const before = dist(a, b);
          const mid0 = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
          prev.x = n.x; prev.y = n.y;
          const after = dist(a, b);
          const mid1 = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
          this.panBy(mid1.x - mid0.x, mid1.y - mid0.y);
          if (before > 0 && after > 0) this.zoomAt(mid1.x, mid1.y, this.zoom + Math.log2(after / before));
        }
      });

      const end = (e) => {
        if (!this.pointers.has(e.pointerId)) return;
        this.pointers.delete(e.pointerId);
        if (this.pointers.size === 0) {
          c.classList.remove('grabbing');
          const t = this.tap;
          this.tap = null;
          if (t && !t.moved && e.type === 'pointerup' && Date.now() - t.t < 600) this._click(t.x, t.y);
        }
      };
      c.addEventListener('pointerup', end);
      c.addEventListener('pointercancel', end);

      c.addEventListener('wheel', (e) => {
        e.preventDefault();
        const p = this._pos(e);
        const d = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY;
        this.zoomAt(p.x, p.y, this.zoom - d * 0.0022);
      }, { passive: false });

      c.addEventListener('dblclick', (e) => {
        const p = this._pos(e);
        this.zoomAt(p.x, p.y, this.zoom + 1);
      });

      c.addEventListener('keydown', (e) => {
        const step = 80;
        const k = e.key;
        if (k === 'ArrowLeft') this.panBy(step, 0);
        else if (k === 'ArrowRight') this.panBy(-step, 0);
        else if (k === 'ArrowUp') this.panBy(0, step);
        else if (k === 'ArrowDown') this.panBy(0, -step);
        else if (k === '+' || k === '=') this.zoomBy(1);
        else if (k === '-' || k === '_') this.zoomBy(-1);
        else return;
        e.preventDefault();
      });
    }

    _click(x, y) {
      let best = null;
      let bestD = 18;
      for (const m of this.markers) {
        const p = this.toScreen(m.lat, m.lng);
        const d = Math.hypot(p.x - x, p.y - y);
        if (d < bestD) { best = m; bestD = d; }
      }
      if (best) this.onSelect(best);
      else this.onTap(this.fromScreen(x, y));
    }

    /* ---- rendering ---- */
    invalidate() {
      if (this.dirty) return;
      this.dirty = true;
      requestAnimationFrame(() => { this.dirty = false; this.draw(); });
    }

    draw() {
      const { ctx, w, h, dpr } = this;
      const dark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = dark ? '#1a2326' : '#e8e2d4';
      ctx.fillRect(0, 0, w, h);
      if (this.hasTiles) this._drawTiles(); else this._drawGrid(dark);
      this._drawOverlay();
    }

    _tile(z, x, y) {
      const key = z + '/' + x + '/' + y;
      let e = this.cache.get(key);
      if (e && e.err && Date.now() - e.errAt > 15000) { this.cache.delete(key); e = null; } // retry later (e.g. back online)
      if (!e) {
        const img = new Image();
        e = { img, ok: false, err: false, errAt: 0 };
        img.onload = () => { e.ok = true; this.invalidate(); };
        img.onerror = () => { e.err = true; e.errAt = Date.now(); };
        img.src = this.tileUrl(z, x, y);
        this.cache.set(key, e);
        if (this.cache.size > 600) {
          let i = 0;
          for (const k of this.cache.keys()) { this.cache.delete(k); if (++i >= 150) break; }
        }
      }
      return e;
    }

    _drawTiles() {
      const ctx = this.ctx;
      const z = clamp(Math.round(this.zoom), this.tileMin, this.tileMax);
      const scale = Math.pow(2, this.zoom - z);
      const n = Math.pow(2, z);
      const c = project(this.lat, this.lng, z);
      const left = c.x - this.w / 2 / scale;
      const top = c.y - this.h / 2 / scale;
      const x0 = Math.floor(left / TILE);
      const x1 = Math.floor((left + this.w / scale) / TILE);
      const y0 = Math.max(0, Math.floor(top / TILE));
      const y1 = Math.min(n - 1, Math.floor((top + this.h / scale) / TILE));
      for (let ty = y0; ty <= y1; ty++) {
        for (let tx = x0; tx <= x1; tx++) {
          const wx = ((tx % n) + n) % n;
          const sx = Math.round((tx * TILE - left) * scale);
          const sy = Math.round((ty * TILE - top) * scale);
          const sw = Math.round(((tx + 1) * TILE - left) * scale) - sx;
          const sh = Math.round(((ty + 1) * TILE - top) * scale) - sy;
          const e = this._tile(z, wx, ty);
          if (e.ok) { ctx.drawImage(e.img, sx, sy, sw, sh); continue; }
          // while loading (or missing) show the parent tile, enlarged, if we already have it
          if (z > this.tileMin) {
            const pe = this.cache.get((z - 1) + '/' + (wx >> 1) + '/' + (ty >> 1));
            if (pe && pe.ok) {
              ctx.drawImage(pe.img, (wx & 1) * 128, (ty & 1) * 128, 128, 128, sx, sy, sw, sh);
            }
          }
        }
      }
    }

    _drawGrid(dark) {
      const ctx = this.ctx;
      const step = 128;
      const c = project(this.lat, this.lng, this.zoom);
      const ox = ((this.w / 2 - c.x) % step + step) % step;
      const oy = ((this.h / 2 - c.y) % step + step) % step;
      ctx.strokeStyle = dark ? 'rgba(255,255,255,.06)' : 'rgba(0,0,0,.07)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let x = ox; x < this.w; x += step) { ctx.moveTo(Math.round(x) + .5, 0); ctx.lineTo(Math.round(x) + .5, this.h); }
      for (let y = oy; y < this.h; y += step) { ctx.moveTo(0, Math.round(y) + .5); ctx.lineTo(this.w, Math.round(y) + .5); }
      ctx.stroke();
    }

    _drawOverlay() {
      const ctx = this.ctx;

      // straight guide line, only while there is no road route
      if (this.me && this.target && !(this.route && this.route.length > 1)) {
        const a = this.toScreen(this.me.lat, this.me.lng);
        const b = this.toScreen(this.target.lat, this.target.lng);
        ctx.save();
        ctx.setLineDash([8, 7]);
        ctx.lineWidth = 3;
        ctx.strokeStyle = 'rgba(43,111,179,.85)';
        ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
        ctx.restore();
      }

      // road route: white casing under a blue line
      if (this.route && this.route.length > 1) {
        ctx.save();
        ctx.lineJoin = 'round'; ctx.lineCap = 'round';
        ctx.beginPath();
        let prev = null;
        for (const [la, ln] of this.route) {
          const p = this.toScreen(la, ln);
          if (prev && Math.abs(p.x - prev.x) + Math.abs(p.y - prev.y) < 1.5 && this.route.length > 400) continue; // thin out sub-pixel points
          if (!prev) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y);
          prev = p;
        }
        ctx.strokeStyle = 'rgba(255,255,255,.95)'; ctx.lineWidth = 9; ctx.stroke();
        ctx.strokeStyle = '#2b6fb3'; ctx.lineWidth = 5.5; ctx.stroke();
        ctx.restore();
      }

      this._drawMarkers();

      // destination flag while navigating
      if (this.target) {
        const p = this.toScreen(this.target.lat, this.target.lng);
        ctx.fillStyle = 'rgba(0,0,0,.2)'; ctx.beginPath(); ctx.arc(p.x, p.y + 2, 13, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(p.x, p.y, 12, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#c0392b'; ctx.beginPath(); ctx.arc(p.x, p.y, 8.5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(p.x, p.y, 3, 0, Math.PI * 2); ctx.fill();
      }

      // user position
      if (this.me) {
        const p = this.toScreen(this.me.lat, this.me.lng);
        const mpp = 156543.03392 * Math.cos(this.me.lat * Math.PI / 180) / Math.pow(2, this.zoom);
        const accPx = (this.me.acc || 0) / mpp;
        if (accPx > 8 && accPx < 400) {
          ctx.fillStyle = 'rgba(43,111,179,.15)';
          ctx.beginPath(); ctx.arc(p.x, p.y, accPx, 0, Math.PI * 2); ctx.fill();
        }
        ctx.fillStyle = '#fff';
        ctx.beginPath(); ctx.arc(p.x, p.y, 10, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#2b6fb3';
        ctx.beginPath(); ctx.arc(p.x, p.y, 7, 0, Math.PI * 2); ctx.fill();
      }
    }

    _drawMarkers() {
      const ctx = this.ctx;
      const z = this.zoom;
      const r = z < 10 ? 3.5 : z < 13 ? 5 : 6.5;
      const vis = [];
      for (const m of this.markers) {
        const p = this.toScreen(m.lat, m.lng);
        if (p.x < -30 || p.y < -30 || p.x > this.w + 30 || p.y > this.h + 30) continue;
        vis.push({ m, p });
      }
      for (const { m, p } of vis) {
        if (m === this.selected) continue;
        ctx.fillStyle = '#fff';
        ctx.beginPath(); ctx.arc(p.x, p.y, r + 1.8, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = m.color || '#555';
        ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, Math.PI * 2); ctx.fill();
      }

      // labels, skipping any that would overlap one already placed (saved places get priority)
      ctx.font = '600 12px system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans Arabic", sans-serif';
      ctx.textBaseline = 'middle';
      ctx.lineJoin = 'round';
      const boxes = [];
      const showLabels = z >= 12.5;
      const order = vis.slice().sort((a, b) => (b.m.priority || 0) - (a.m.priority || 0));
      for (const { m, p } of order) {
        if (m === this.selected) continue;
        if (!showLabels && !m.priority) continue;
        const tw = ctx.measureText(m.name).width;
        const box = { x: p.x + r + 5, y: p.y - 8, w: tw + 4, h: 16 };
        if (boxes.some((b) => box.x < b.x + b.w && box.x + box.w > b.x && box.y < b.y + b.h && box.y + box.h > b.y)) continue;
        boxes.push(box);
        this._label(m.name, box.x, p.y);
      }

      if (this.selected) {
        const s = vis.find((v) => v.m === this.selected);
        const p = s ? s.p : this.toScreen(this.selected.lat, this.selected.lng);
        const col = this.selected.color || '#c0392b';
        ctx.fillStyle = 'rgba(0,0,0,.18)';
        ctx.beginPath(); ctx.arc(p.x, p.y + 2, r + 7, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.beginPath(); ctx.arc(p.x, p.y, r + 6, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = col;
        ctx.beginPath(); ctx.arc(p.x, p.y, r + 3.5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.beginPath(); ctx.arc(p.x, p.y, 2.5, 0, Math.PI * 2); ctx.fill();
        this._label(this.selected.name, p.x + r + 11, p.y);
      }
    }

    _label(text, x, y) {
      const ctx = this.ctx;
      ctx.lineWidth = 3.5;
      ctx.strokeStyle = 'rgba(255,255,255,.92)';
      ctx.strokeText(text, x, y);
      ctx.fillStyle = '#1b2a2c';
      ctx.fillText(text, x, y);
    }
  }

  root.SlippyMap = SlippyMap;
  root.MapMath = { project, unproject, TILE };
  if (typeof module !== 'undefined' && module.exports) module.exports = { SlippyMap, MapMath: root.MapMath };
})(typeof window !== 'undefined' ? window : globalThis);
