/*
 * Offline road router: A* on the compact graph made by tools/build-graph.js.
 * Runs entirely in the browser (or Node, for tests). No dependencies.
 */
(function (root) {
  'use strict';

  const R = 6371008.8, RAD = Math.PI / 180;
  const VMAX = 130 / 3.6;      // m/s, keeps the A* heuristic admissible
  const JUNCTION_S = 4;        // seconds lost per junction
  const CELL = 0.003;          // snapping grid cell, degrees (~330 m)

  const hav = (la1, ln1, la2, ln2) => {
    const dl = (la2 - la1) * RAD, dg = (ln2 - ln1) * RAD;
    const x = Math.sin(dl / 2) ** 2 + Math.cos(la1 * RAD) * Math.cos(la2 * RAD) * Math.sin(dg / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(x));
  };
  const bearing = (a, b) => {
    const y = Math.sin((b[1] - a[1]) * RAD) * Math.cos(b[0] * RAD);
    const x = Math.cos(a[0] * RAD) * Math.sin(b[0] * RAD) - Math.sin(a[0] * RAD) * Math.cos(b[0] * RAD) * Math.cos((b[1] - a[1]) * RAD);
    return (Math.atan2(y, x) / RAD + 360) % 360;
  };
  const COMPASS = ['north', 'north-east', 'east', 'south-east', 'south', 'south-west', 'west', 'north-west'];

  class Heap {
    constructor() { this.k = []; this.v = []; }
    get size() { return this.k.length; }
    push(key, val) {
      const k = this.k, v = this.v; let i = k.length; k.push(key); v.push(val);
      while (i > 0) { const p = (i - 1) >> 1; if (k[p] <= key) break; k[i] = k[p]; v[i] = v[p]; i = p; }
      k[i] = key; v[i] = val;
    }
    pop() {
      const k = this.k, v = this.v, topK = k[0], topV = v[0], lastK = k.pop(), lastV = v.pop(), n = k.length;
      if (n) {
        let i = 0;
        for (;;) {
          let c = 2 * i + 1; if (c >= n) break;
          if (c + 1 < n && k[c + 1] < k[c]) c++;
          if (k[c] >= lastK) break;
          k[i] = k[c]; v[i] = v[c]; i = c;
        }
        k[i] = lastK; v[i] = lastV;
      }
      return [topK, topV];
    }
  }

  function createRouter(g) {
    const nn = g.nodes.length / 2, ne = g.edges.length / 8, E = g.edges;
    const nlat = (i) => g.nodes[2 * i] / 1e6, nlng = (i) => g.nodes[2 * i + 1] / 1e6;
    const from = (e) => E[e * 8], to = (e) => E[e * 8 + 1], len = (e) => E[e * 8 + 2], spd = (e) => E[e * 8 + 3];
    const nameOf = (e) => g.names[E[e * 8 + 4]] || '';
    const cost = (e) => len(e) / (spd(e) / 3.6) + JUNCTION_S;

    // adjacency (CSR)
    const start = new Int32Array(nn + 1);
    for (let e = 0; e < ne; e++) start[from(e) + 1]++;
    for (let i = 0; i < nn; i++) start[i + 1] += start[i];
    const out = new Int32Array(ne), fill = start.slice(0, nn);
    for (let e = 0; e < ne; e++) out[fill[from(e)]++] = e;

    // geometry of an edge in travel order: [[lat,lng], ...] including both end junctions
    function pts(e) {
      const p = [[nlat(from(e)), nlng(from(e))]];
      const ss = E[e * 8 + 5], sn = E[e * 8 + 6];
      for (let k = 0; k < sn; k++) p.push([g.shape[2 * (ss + k)] / 1e6, g.shape[2 * (ss + k) + 1] / 1e6]);
      p.push([nlat(to(e)), nlng(to(e))]);
      return p;
    }

    // -------- snapping
    let grid = null;
    function buildGrid() {
      grid = new Map();
      for (let e = 0; e < ne; e++) {
        if (!(E[e * 8 + 7] & 2)) continue;
        const p = pts(e), seen = new Set();
        for (let k = 0; k + 1 < p.length; k++) {
          const x0 = Math.floor(Math.min(p[k][1], p[k + 1][1]) / CELL), x1 = Math.floor(Math.max(p[k][1], p[k + 1][1]) / CELL);
          const y0 = Math.floor(Math.min(p[k][0], p[k + 1][0]) / CELL), y1 = Math.floor(Math.max(p[k][0], p[k + 1][0]) / CELL);
          for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
            const key = y * 100003 + x;
            if (seen.has(key)) continue; seen.add(key);
            let a = grid.get(key); if (!a) grid.set(key, a = []); a.push(e);
          }
        }
      }
    }

    function twinOf(e) {
      for (let k = start[to(e)]; k < start[to(e) + 1]; k++) {
        const t = out[k];
        if (to(t) === from(e) && Math.abs(len(t) - len(e)) <= 1 && E[t * 8 + 4] === E[e * 8 + 4]) return t;
      }
      return -1;
    }

    function snap(lat, lng, maxM = 1500) {
      if (!grid) buildGrid();
      const kx = Math.cos(lat * RAD) * 111320, ky = 110540;
      const cy = Math.floor(lat / CELL), cx = Math.floor(lng / CELL);
      let best = null;
      const rings = Math.ceil(maxM / (CELL * ky)) + 1;
      for (let r = 0; r <= rings; r++) {
        for (let y = cy - r; y <= cy + r; y++) for (let x = cx - r; x <= cx + r; x++) {
          if (Math.max(Math.abs(y - cy), Math.abs(x - cx)) !== r) continue;
          const list = grid.get(y * 100003 + x); if (!list) continue;
          for (const e of list) {
            const p = pts(e); let along = 0;
            for (let k = 0; k + 1 < p.length; k++) {
              const ax = (p[k][1] - lng) * kx, ay = (p[k][0] - lat) * ky, bx = (p[k + 1][1] - lng) * kx, by = (p[k + 1][0] - lat) * ky;
              const dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
              let t = l2 ? -(ax * dx + ay * dy) / l2 : 0; t = Math.max(0, Math.min(1, t));
              const px = ax + dx * t, py = ay + dy * t, d = Math.hypot(px, py), segLen = Math.sqrt(l2);
              if (!best || d < best.off) best = { e, off: d, along: along + t * segLen, point: [lat + py / ky, lng + px / kx] };
              along += segLen;
            }
          }
        }
        if (best && best.off <= (r) * CELL * ky * 0.9) break; // nothing in a further ring can be closer
      }
      if (!best || best.off > maxM) return null;
      // convert "along" (planar metres) to the edge's stored length scale
      const p = pts(best.e); let tot = 0;
      for (let k = 0; k + 1 < p.length; k++) tot += Math.hypot((p[k + 1][1] - p[k][1]) * kx, (p[k + 1][0] - p[k][0]) * ky);
      best.frac = tot ? Math.min(1, best.along / tot) : 0;
      best.twin = twinOf(best.e);
      return best;
    }

    // slice a polyline between two fractions of its length (a > b allowed => reversed)
    function slice(p, f0, f1) {
      const cum = [0]; for (let k = 1; k < p.length; k++) cum.push(cum[k - 1] + hav(p[k - 1][0], p[k - 1][1], p[k][0], p[k][1]));
      const tot = cum[cum.length - 1] || 1;
      const at = (d) => {
        for (let k = 1; k < p.length; k++) if (cum[k] >= d) { const t = (d - cum[k - 1]) / ((cum[k] - cum[k - 1]) || 1); return [p[k - 1][0] + (p[k][0] - p[k - 1][0]) * t, p[k - 1][1] + (p[k][1] - p[k - 1][1]) * t, k]; }
        return [p[p.length - 1][0], p[p.length - 1][1], p.length - 1];
      };
      const d0 = f0 * tot, d1 = f1 * tot;
      if (d0 <= d1) {
        const a = at(d0), b = at(d1), mid = [];
        for (let k = a[2]; k < b[2]; k++) mid.push(p[k]);
        return [[a[0], a[1]], ...mid, [b[0], b[1]]];
      }
      const rp = p.slice().reverse(); return slice(rp, 1 - f0, 1 - f1);
    }

    // -------- routing
    function route(fromLL, toLL) {
      const s = snap(fromLL[0], fromLL[1]), t = snap(toLL[0], toLL[1]);
      if (!s || !t) return { error: !s ? 'start-off-network' : 'end-off-network' };
      const secs = (e, f) => f * len(e) / (spd(e) / 3.6);

      // driving along one edge (same road segment, destination ahead or behind)
      if (s.e === t.e) {
        if (t.frac >= s.frac) return finish(s, t, fromLL, toLL, [{ e: s.e, f0: s.frac, f1: t.frac }], secs(s.e, t.frac - s.frac));
        if (s.twin >= 0) return finish(s, t, fromLL, toLL, [{ e: s.twin, f0: 1 - s.frac, f1: 1 - t.frac }], secs(s.twin, s.frac - t.frac));
      }

      // seeds: where the journey can start. leg = partial first edge (null when standing on a junction)
      const seeds = [{ node: to(s.e), cost: secs(s.e, 1 - s.frac), leg: { e: s.e, f0: s.frac, f1: 1 } }];
      if (s.twin >= 0) seeds.push({ node: to(s.twin), cost: secs(s.twin, s.frac), leg: { e: s.twin, f0: 1 - s.frac, f1: 1 } });
      if (s.frac * len(s.e) < 3) seeds.push({ node: from(s.e), cost: 0, leg: null });
      if ((1 - s.frac) * len(s.e) < 3) seeds.push({ node: to(s.e), cost: 0, leg: null });

      // goals: nodes from which the destination is reached, with the cost of the final partial edge
      const goals = new Map();
      const addGoal = (node, extra, leg) => { const g = goals.get(node); if (!g || extra < g.extra) goals.set(node, { extra, leg }); };
      addGoal(from(t.e), secs(t.e, t.frac), { e: t.e, f0: 0, f1: t.frac });
      if (t.twin >= 0) addGoal(from(t.twin), secs(t.twin, 1 - t.frac), { e: t.twin, f0: 0, f1: 1 - t.frac });
      if (t.frac * len(t.e) < 3) addGoal(from(t.e), 0, null);
      if ((1 - t.frac) * len(t.e) < 3) addGoal(to(t.e), 0, null);

      const dist = new Float64Array(nn).fill(Infinity), pe = new Int32Array(nn).fill(-1), seedAt = new Map();
      const heap = new Heap(), tlat = toLL[0], tlng = toLL[1];
      const h = (n) => hav(nlat(n), nlng(n), tlat, tlng) / VMAX;
      for (const sd of seeds) {
        if (sd.cost < dist[sd.node]) { dist[sd.node] = sd.cost; pe[sd.node] = -1; seedAt.set(sd.node, sd); heap.push(sd.cost + h(sd.node), sd.node); }
      }
      let best = Infinity, bestGoal = -1;
      while (heap.size) {
        const [f, n] = heap.pop();
        if (f >= best) break;
        const g0 = dist[n];
        if (f - h(n) > g0 + 1e-6) continue; // stale entry
        const goal = goals.get(n);
        if (goal && g0 + goal.extra < best) { best = g0 + goal.extra; bestGoal = n; }
        for (let k = start[n]; k < start[n + 1]; k++) {
          const e = out[k], m = to(e), nd = g0 + cost(e);
          if (nd < dist[m]) { dist[m] = nd; pe[m] = e; heap.push(nd + h(m), m); }
        }
      }
      if (bestGoal < 0) return { error: 'no-route' };

      const mid = []; let n = bestGoal;
      while (pe[n] !== -1) { mid.push(pe[n]); n = from(pe[n]); }
      const legs = [];
      const sd = seedAt.get(n); if (sd.leg) legs.push(sd.leg);
      for (let k = mid.length - 1; k >= 0; k--) legs.push({ e: mid[k], f0: 0, f1: 1 });
      const gl = goals.get(bestGoal).leg; if (gl) legs.push(gl);
      return finish(s, t, fromLL, toLL, legs, best);
    }

    function finish(s, t, fromLL, toLL, legs, seconds) {
      const coords = [fromLL, s.point];
      const legInfo = [];
      for (const lg of legs) {
        const seg = slice(pts(lg.e), lg.f0, lg.f1);
        let d = 0; for (let k = 1; k < seg.length; k++) d += hav(seg[k - 1][0], seg[k - 1][1], seg[k][0], seg[k][1]);
        if (d < 0.5) continue;
        legInfo.push({ e: lg.e, seg, d, name: nameOf(lg.e) });
        for (let k = 1; k < seg.length; k++) coords.push(seg[k]);
      }
      coords.push(t.point, toLL);
      const cum = [0]; for (let k = 1; k < coords.length; k++) cum.push(cum[k - 1] + hav(coords[k - 1][0], coords[k - 1][1], coords[k][0], coords[k][1]));
      const lead = cum[1]; // metres from the typed start to the road
      return { coords, cum, distance: cum[cum.length - 1], duration: seconds, steps: steps(legInfo, lead, toLL), offRoadStart: s.off, offRoadEnd: t.off };
    }

    function dirAt(seg, atEnd) {
      // bearing over (up to) the last/first ~15 m of a leg
      if (seg.length < 2) return null;
      let acc = 0;
      if (atEnd) { for (let k = seg.length - 1; k > 0; k--) { acc += hav(seg[k][0], seg[k][1], seg[k - 1][0], seg[k - 1][1]); if (acc >= 15 || k === 1) return bearing(seg[k - 1], seg[seg.length - 1]); } }
      else { for (let k = 1; k < seg.length; k++) { acc += hav(seg[k][0], seg[k][1], seg[k - 1][0], seg[k - 1][1]); if (acc >= 15 || k === seg.length - 1) return bearing(seg[0], seg[k]); } }
      return null;
    }

    function steps(legs, lead, dest) {
      const out = [];
      if (!legs.length) return [{ type: 'arrive', text: 'You are at your destination', at: 0, lat: dest[0], lng: dest[1] }];
      let at = lead;
      const first = legs[0];
      const b0 = dirAt(first.seg, false);
      out.push({ type: 'depart', text: `Head ${COMPASS[Math.round((b0 || 0) / 45) % 8]}${first.name ? ' on ' + first.name : ''}`, name: first.name, at: 0, lat: first.seg[0][0], lng: first.seg[0][1] });
      for (let i = 1; i < legs.length; i++) {
        const prev = legs[i - 1], cur = legs[i];
        at += prev.d;
        const a = dirAt(prev.seg, true), b = dirAt(cur.seg, false);
        if (a == null || b == null) continue;
        let turn = ((b - a + 540) % 360) - 180;
        const sameName = (prev.name || '') === (cur.name || '');
        const abs = Math.abs(turn);
        let kind;
        if (abs < 25) kind = 'straight';
        else if (abs < 60) kind = turn > 0 ? 'slight right' : 'slight left';
        else if (abs < 135) kind = turn > 0 ? 'right' : 'left';
        else if (abs < 170) kind = turn > 0 ? 'sharp right' : 'sharp left';
        else kind = 'u-turn';
        if (kind === 'straight' && (sameName || !cur.name)) continue;
        const text = kind === 'straight' ? `Continue onto ${cur.name}`
          : kind === 'u-turn' ? 'Make a U-turn'
          : `Turn ${kind}${cur.name ? ' onto ' + cur.name : ''}`;
        out.push({ type: kind === 'straight' ? 'continue' : 'turn', dir: kind, text, name: cur.name, at, lat: cur.seg[0][0], lng: cur.seg[0][1] });
      }
      const last = legs[legs.length - 1];
      out.push({ type: 'arrive', text: 'Arrive at your destination', at: at + last.d, lat: last.seg[last.seg.length - 1][0], lng: last.seg[last.seg.length - 1][1] });
      return out;
    }

    return { route, snap, stats: { nodes: nn, edges: ne } };
  }

  // Where is a point relative to a computed route? { off: metres from the route, along: metres travelled }
  function locate(r, lat, lng) {
    const c = r.coords, kx = Math.cos(lat * RAD) * 111320, ky = 110540;
    let best = { off: Infinity, along: 0 };
    for (let k = 0; k + 1 < c.length; k++) {
      const ax = (c[k][1] - lng) * kx, ay = (c[k][0] - lat) * ky, bx = (c[k + 1][1] - lng) * kx, by = (c[k + 1][0] - lat) * ky;
      const dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
      let t = l2 ? -(ax * dx + ay * dy) / l2 : 0; t = Math.max(0, Math.min(1, t));
      const d = Math.hypot(ax + dx * t, ay + dy * t);
      if (d < best.off) best = { off: d, along: r.cum[k] + t * Math.sqrt(l2), seg: k };
    }
    return best;
  }

  function pointAlong(r, d) {
    const c = r.coords;
    for (let k = 1; k < c.length; k++) if (r.cum[k] >= d) {
      const t = (d - r.cum[k - 1]) / ((r.cum[k] - r.cum[k - 1]) || 1);
      return [c[k - 1][0] + (c[k][0] - c[k - 1][0]) * t, c[k - 1][1] + (c[k][1] - c[k - 1][1]) * t];
    }
    return c[c.length - 1];
  }

  root.Router = { createRouter, locate, pointAlong, hav, bearing };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.Router;
})(typeof window !== 'undefined' ? window : globalThis);
