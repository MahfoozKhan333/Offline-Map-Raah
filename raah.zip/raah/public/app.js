/* Raah - app logic. No frameworks; all user-provided text is inserted with textContent. */
(() => {
  'use strict';

  /* ================================================================ helpers */
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat()) {
      if (kid == null || kid === false) continue;
      el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return el;
  }

  const ICONS = {
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    locate: '<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="8"/><path d="M12 1.5v3M12 19.5v3M1.5 12h3M19.5 12h3"/>',
    close: '<path d="M6 6l12 12M18 6 6 18"/>',
    dashboard: '<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>',
    map: '<path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2z"/><path d="M9 4v14M15 6v14"/>',
    bookmark: '<path d="M6 3h12v18l-6-4-6 4z"/>',
    download: '<path d="M12 3v12m0 0-4-4m4 4 4-4M4 20h16"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.5 3-6 6.5-6s6.5 2.5 6.5 6"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14c2 .7 3.5 2.6 3.5 6"/>',
    logout: '<path d="M9 4H5v16h4M16 8l4 4-4 4M20 12H9"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  };
  function icon(name) {
    const t = document.createElement('template');
    t.innerHTML = `<svg class="ico" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ''}</svg>`;
    return t.content.firstChild;
  }

  const store = {
    get(k, d) { try { const v = localStorage.getItem('raah:' + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem('raah:' + k, JSON.stringify(v)); } catch { /* storage full or blocked */ } },
    del(k) { try { localStorage.removeItem('raah:' + k); } catch { /* ignore */ } },
  };

  let toastTimer = 0;
  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 3200);
  }

  class NetError extends Error {}
  async function api(path, { method = 'GET', body } = {}) {
    let res;
    try {
      res = await fetch(path, {
        method,
        credentials: 'same-origin',
        headers: method === 'GET' ? {} : { 'Content-Type': 'application/json' },
        body: method === 'GET' ? undefined : JSON.stringify(body || {}),
      });
    } catch { throw new NetError('offline'); }
    let data = null;
    try { data = await res.json(); } catch { /* empty body */ }
    if (!res.ok) {
      const e = new Error((data && data.error) || `Request failed (${res.status})`);
      e.status = res.status;
      throw e;
    }
    return data;
  }

  const fmtDist = (m) => (m < 1000 ? `${Math.round(m / 10) * 10 || Math.round(m)} m` : `${(m / 1000).toFixed(m < 10000 ? 1 : 0)} km`);
  const fmtBytes = (b) => (b == null ? '-' : b < 1048576 ? `${Math.round(b / 1024)} KB` : b < 1073741824 ? `${(b / 1048576).toFixed(1)} MB` : `${(b / 1073741824).toFixed(2)} GB`);
  const fmtDur = (min) => (min < 1 ? '< 1 min' : min < 60 ? `${Math.round(min)} min` : `${Math.floor(min / 60)} h ${Math.round(min % 60)} min`);

  function haversine(a, b) {
    const R = 6371008.8, r = Math.PI / 180;
    const dLat = (b.lat - a.lat) * r, dLng = (b.lng - a.lng) * r;
    const x = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * r) * Math.cos(b.lat * r) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(x));
  }
  function bearing(a, b) {
    const r = Math.PI / 180;
    const y = Math.sin((b.lng - a.lng) * r) * Math.cos(b.lat * r);
    const x = Math.cos(a.lat * r) * Math.sin(b.lat * r) - Math.sin(a.lat * r) * Math.cos(b.lat * r) * Math.cos((b.lng - a.lng) * r);
    return (Math.atan2(y, x) / r + 360) % 360;
  }
  const COMPASS = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  const compassPoint = (deg) => COMPASS[Math.round(deg / 45) % 8];

  /* ================================================================== state */
  const CATS = {
    landmark: { label: 'Landmark', color: '#c8962e', kw: 'landmark attraction sightseeing tourist' },
    mall: { label: 'Shopping', color: '#7a4fb5', kw: 'mall shopping shop store' },
    transport: { label: 'Transport', color: '#2b6fb3', kw: 'airport metro station port bus ferry transport' },
    culture: { label: 'Culture & heritage', color: '#b3592f', kw: 'museum heritage souk souq market mosque culture' },
    leisure: { label: 'Parks & leisure', color: '#2f8f5b', kw: 'park beach garden lake fun leisure' },
    district: { label: 'Area', color: '#5b6b73', kw: 'area neighbourhood neighborhood community district' },
    health: { label: 'Healthcare', color: '#c0392b', kw: 'hospital clinic doctor medical health' },
    hotel: { label: 'Hotel', color: '#1d8f94', kw: 'hotel resort stay' },
    saved: { label: 'Saved', color: '#e0457b', kw: 'saved favourite favorite' },
    pin: { label: 'Dropped pin', color: '#222222', kw: '' },
  };

  const S = {
    user: null, places: [], index: [], saved: [], tiles: null, map: null,
    selected: null, nav: null, watchId: null, me: null, heading: null,
    flushing: false, installEvent: null, dl: { preset: 'dubai', maxZ: 15, running: false, ctrl: null, progress: null },
  };

  const DUBAI = { lat: 25.2048, lng: 55.2708, zoom: 11 };
  const uk = (name) => `${name}:${S.user ? S.user.id : 0}`;

  /* ============================================================ service worker */
  function registerSW() {
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
    window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); S.installEvent = e; rerenderIfView('offline'); rerenderIfView('dashboard'); });
    window.addEventListener('appinstalled', () => { S.installEvent = null; toast('Raah installed'); });
  }

  /* ==================================================================== auth */
  function showAuth(cfg) {
    $('#app').hidden = true;
    $('#auth').hidden = false;
    const open = !cfg || cfg.registration;
    $('#tabRegister').hidden = !open;
    $('#authClosed').hidden = open;
    $('#firstUserNote').hidden = !(cfg && cfg.firstUser);
    if (cfg && cfg.firstUser) setAuthTab('register');
    else setAuthTab('login');
  }

  function setAuthTab(which) {
    const reg = which === 'register';
    $('#loginForm').hidden = reg;
    $('#registerForm').hidden = !reg;
    $('#tabLogin').setAttribute('aria-selected', String(!reg));
    $('#tabRegister').setAttribute('aria-selected', String(reg));
    $('#authError').textContent = '';
  }

  async function submitAuth(form, path) {
    const err = $('#authError');
    err.textContent = '';
    const btn = $('button[type=submit]', form);
    btn.disabled = true;
    const data = Object.fromEntries(new FormData(form));
    try {
      const { user } = await api(path, { method: 'POST', body: data });
      form.reset();
      S.user = user;
      store.set('user', user);
      enterApp();
    } catch (e) {
      err.textContent = e instanceof NetError ? 'No internet connection. You need to be online the first time you sign in.' : e.message;
    } finally { btn.disabled = false; }
  }

  async function logout() {
    stopNav();
    try { await api('/api/logout', { method: 'POST' }); } catch { toast('Signed out on this device. Sign-out on the server will complete when you are online.'); }
    store.del('user');
    S.user = null; S.saved = []; S.selected = null;
    $('#userMenu').hidden = true;
    location.hash = '';
    const cfg = await api('/api/config').catch(() => null);
    showAuth(cfg);
  }

  function sessionExpired() {
    toast('Your session expired. Please sign in again.');
    store.del('user');
    S.user = null;
    api('/api/config').catch(() => null).then(showAuth);
  }

  /* ============================================================== app start */
  async function enterApp() {
    $('#auth').hidden = true;
    $('#app').hidden = false;
    const u = S.user;
    $('#userBtn').textContent = (u.name.trim()[0] || '?').toUpperCase();
    $('#menuName').textContent = u.name;
    $('#menuEmail').textContent = u.email;
    $('#navAdmin').hidden = u.role !== 'admin';
    $$('[data-icon]').forEach((el) => { if (!el.dataset.done) { el.prepend(icon(el.dataset.icon)); el.dataset.done = '1'; } });
    updateNet();

    S.saved = store.get(uk('saved'), []);
    S.tiles = store.get('tilestatus', null);
    await loadPlaces();
    route();
    refreshTileStatus();
    flushQueue();
  }

  async function loadPlaces() {
    if (S.places.length) return;
    try {
      const res = await fetch('/data/places.json');
      const data = await res.json();
      S.places = data.places || [];
    } catch { S.places = []; toast('Could not load the places database.'); }
    S.index = S.places.map((p) => makeIndexEntry(p, CATS[p.cat] || CATS.landmark));
  }

  async function refreshTileStatus() {
    try {
      S.tiles = await api('/api/tiles/status');
      store.set('tilestatus', S.tiles);
    } catch (e) {
      if (e.status === 401) return sessionExpired();
    }
    if (S.map) configureMapTiles();
    rerenderIfView('dashboard');
    rerenderIfView('offline');
  }

  /* ============================================================== networking */
  function updateNet() {
    const on = navigator.onLine;
    const pill = $('#netpill');
    pill.textContent = on ? 'Online' : 'Offline mode';
    pill.classList.toggle('off', !on);
    rerenderIfView('dashboard');
  }
  window.addEventListener('online', () => { updateNet(); flushQueue(); refreshTileStatus(); });
  window.addEventListener('offline', updateNet);

  /* ================================================================== router */
  const VIEWS = ['dashboard', 'map', 'saved', 'offline', 'admin'];
  function parseHash() {
    const raw = location.hash.replace(/^#\/?/, '');
    const [name, qs] = raw.split('?');
    return { name: VIEWS.includes(name) ? name : 'dashboard', params: new URLSearchParams(qs || '') };
  }
  function currentView() { return parseHash().name; }
  function rerenderIfView(name) { if (S.user && currentView() === name) renderView(name); }

  function route() {
    if (!S.user) return;
    const { name, params } = parseHash();
    if (name === 'admin' && S.user.role !== 'admin') { location.hash = '#/dashboard'; return; }
    $$('.view').forEach((v) => v.classList.toggle('active', v.id === 'v-' + name));
    $$('.nav a').forEach((a) => a.classList.toggle('active', a.dataset.view === name));
    renderView(name);
    if (name === 'map' && params.get('ll')) {
      const m = /^(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)$/.exec(params.get('ll'));
      if (m) selectPlace({ id: 'pin', cat: 'pin', name: (params.get('n') || 'Shared location').slice(0, 80), lat: +m[1], lng: +m[2] }, { zoom: 16 });
    }
  }
  window.addEventListener('hashchange', route);

  function renderView(name) {
    if (name === 'dashboard') renderDashboard();
    else if (name === 'map') showMap();
    else if (name === 'saved') renderSaved();
    else if (name === 'offline') renderOffline();
    else if (name === 'admin') renderAdmin();
  }

  /* ================================================================== search */
  const norm = (s) => String(s || '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^\p{L}\p{N}\s]/gu, ' ').replace(/\s+/g, ' ').trim();

  function makeIndexEntry(p, cat) {
    const names = [p.name, p.ar, ...(p.alt || [])].filter(Boolean).map(norm);
    return { p, names, hay: [...names, norm(p.area), norm(cat.label), norm(cat.kw)].join(' | ') };
  }

  function searchPlaces(query) {
    const out = [];
    const qn = norm(query);
    const coord = /^\s*(-?\d{1,2}(?:\.\d+)?)\s*[, ]\s*(-?\d{1,3}(?:\.\d+)?)\s*$/.exec(query);
    if (coord && Math.abs(+coord[1]) <= 90 && Math.abs(+coord[2]) <= 180) {
      out.push({ place: { id: 'pin', cat: 'pin', name: `${(+coord[1]).toFixed(5)}, ${(+coord[2]).toFixed(5)}`, area: 'Go to coordinates', lat: +coord[1], lng: +coord[2] }, score: 1000 });
    }
    if (!qn) return out;
    const toks = qn.split(' ');
    const pool = [...savedMarkers().map((m) => makeIndexEntry(m, CATS.saved)), ...S.index];
    for (const e of pool) {
      if (!toks.every((t) => e.hay.includes(t))) continue;
      let score = 30;
      if (e.names.some((n) => n.startsWith(qn))) score = 100;
      else if (e.names.some((n) => n.split(' ').some((w) => w.startsWith(toks[0])))) score = 80;
      else if (e.names.some((n) => n.includes(qn))) score = 60;
      if (e.p.cat === 'saved') score += 15;
      score += (e.p.pop || 0) * 4; // well-known places first ("burj" -> Burj Khalifa, not a small mall)
      score -= Math.min(10, e.p.name.length / 10);
      out.push({ place: e.p, score });
    }
    return out.sort((a, b) => b.score - a.score).slice(0, 8);
  }

  const resultsEl = () => $('#results');
  let shown = [];
  let active = -1;

  function renderResults() {
    const input = $('#q');
    const q = input.value.trim();
    const box = resultsEl();
    box.replaceChildren();
    shown = [];
    active = -1;

    if (!q) {
      const recent = store.get(uk('recent'), []);
      if (!recent.length) { closeResults(); return; }
      box.append(h('div', { class: 'r-head' }, 'Recent'));
      recent.slice(0, 6).forEach((r) => addResultRow(r.place || r, r.place ? '' : '', true));
    } else {
      const res = searchPlaces(q);
      if (!res.length) {
        box.append(h('div', { class: 'r-empty' }, 'No match in your offline places. You can type coordinates like "25.2, 55.27" or tap the map to drop a pin.'));
      } else res.forEach((r) => addResultRow(r.place));
    }
    box.hidden = false;
    input.setAttribute('aria-expanded', 'true');
  }

  function addResultRow(p) {
    const cat = CATS[p.cat] || CATS.landmark;
    const idx = shown.length;
    shown.push(p);
    const row = h('div', { class: 'r-item', role: 'option', id: 'r' + idx, 'aria-selected': 'false' },
      h('span', { class: 'r-dot' }),
      h('div', { class: 'r-main' }, h('b', {}, p.name), h('span', {}, [cat.label, p.area].filter(Boolean).join(' · '))));
    $('.r-dot', row).style.background = cat.color;
    row.addEventListener('mousedown', (e) => { e.preventDefault(); chooseResult(p); });
    resultsEl().append(row);
  }

  function setActive(i) {
    const rows = $$('.r-item', resultsEl());
    if (!rows.length) return;
    active = (i + rows.length) % rows.length;
    rows.forEach((r, n) => r.setAttribute('aria-selected', String(n === active)));
    rows[active].scrollIntoView({ block: 'nearest' });
    $('#q').setAttribute('aria-activedescendant', 'r' + active);
  }

  function closeResults() {
    resultsEl().hidden = true;
    $('#q').setAttribute('aria-expanded', 'false');
    $('#q').removeAttribute('aria-activedescendant');
  }

  function chooseResult(p) {
    const recent = store.get(uk('recent'), []).filter((r) => r.name !== p.name);
    recent.unshift({ id: p.id, name: p.name, cat: p.cat, area: p.area, lat: p.lat, lng: p.lng });
    store.set(uk('recent'), recent.slice(0, 8));
    $('#q').value = '';
    closeResults();
    $('#q').blur();
    if (currentView() !== 'map') { S.pendingSelect = p; location.hash = '#/map'; } else selectPlace(p);
  }

  function bindSearch() {
    const input = $('#q');
    input.addEventListener('input', renderResults);
    input.addEventListener('focus', renderResults);
    input.addEventListener('blur', () => setTimeout(() => { if (document.activeElement !== input) closeResults(); }, 120));
    input.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); if (resultsEl().hidden) renderResults(); setActive(active + 1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(active - 1); }
      else if (e.key === 'Enter') { e.preventDefault(); const p = shown[active >= 0 ? active : 0]; if (p) chooseResult(p); }
      else if (e.key === 'Escape') { closeResults(); input.blur(); }
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName) && S.user) { e.preventDefault(); input.focus(); }
    });
  }

  function searchFor(text) { const i = $('#q'); i.value = text; i.focus(); renderResults(); }

  /* ====================================================================== map */
  function savedMarkers() {
    return S.saved.map((s) => ({ id: 's' + s.id, savedId: s.id, cat: 'saved', name: s.name, area: s.note, lat: s.lat, lng: s.lng }));
  }

  function allMarkers() {
    return [
      ...S.places.map((p) => ({ ...p, color: (CATS[p.cat] || CATS.landmark).color })),
      ...savedMarkers().map((m) => ({ ...m, color: CATS.saved.color, priority: 2 })),
    ];
  }

  function refreshMarkers() {
    if (!S.map) return;
    S.map.setMarkers(allMarkers());
    if (S.selected) {
      S.map.selected = S.map.markers.find((m) => m.id === S.selected.id && m.lat === S.selected.lat) || S.map.selected;
    }
  }

  function configureMapTiles() {
    const t = S.tiles;
    const ok = !!(t && t.installed && !t.vector);
    S.map.setTileRange(t && Number.isFinite(t.minzoom) ? t.minzoom : 0, t && Number.isFinite(t.maxzoom) ? t.maxzoom : 19, ok);
    $('#attrib').textContent = ok ? (t.attribution || 'Map data: see your tile provider\'s licence') : '';
    $('#attrib').hidden = !ok;
    const msg = $('#mapMsg');
    if (!t) { msg.hidden = true; return; }
    if (!t.installed) {
      msg.hidden = false;
      msg.textContent = 'No map tiles are installed on the server yet, so the background is blank. Search and saved places still work. See README.md to add a Dubai map file.';
    } else if (t.vector) {
      msg.hidden = false;
      msg.textContent = 'The installed map file uses vector tiles, which this version does not draw yet. Please use a raster (PNG/JPG) MBTiles file.';
    } else msg.hidden = true;
  }

  function showMap() {
    if (!S.map) {
      S.map = new SlippyMap($('#mapc'), {
        onSelect: (m) => selectPlace(m, { fly: false }),
        onTap: (ll) => selectPlace({ id: 'pin', cat: 'pin', name: 'Dropped pin', lat: ll.lat, lng: ll.lng }, { fly: false }),
      });
      new ResizeObserver(() => S.map.resize()).observe($('#v-map'));
      const c = S.tiles && S.tiles.center;
      S.map.setView(c ? c[1] : DUBAI.lat, c ? c[0] : DUBAI.lng, c && c[2] ? c[2] : DUBAI.zoom);
      configureMapTiles();
      refreshMarkers();
    }
    requestAnimationFrame(() => { S.map.resize(); });
    if (S.pendingSelect) { const p = S.pendingSelect; S.pendingSelect = null; selectPlace(p); }
    else if (S.selected) renderCard();
    updateNavUI();
  }

  function selectPlace(p, opts = {}) {
    S.selected = p;
    if (S.map) {
      const marker = S.map.markers.find((m) => m.id === p.id && m.lat === p.lat && m.lng === p.lng);
      S.map.selected = marker || { ...p, color: (CATS[p.cat] || CATS.pin).color };
      if (opts.fly !== false) S.map.flyTo(p.lat, p.lng, Math.max(S.map.zoom, opts.zoom || 15));
      S.map.invalidate();
    }
    renderCard();
  }

  function findSaved(p) {
    return S.saved.find((s) => s.id === p.savedId) ||
      S.saved.find((s) => s.name === p.name && Math.abs(s.lat - p.lat) < 1e-5 && Math.abs(s.lng - p.lng) < 1e-5);
  }

  function renderCard() {
    const card = $('#card');
    const p = S.selected;
    if (!p) { card.hidden = true; return; }
    const cat = CATS[p.cat] || CATS.pin;
    const saved = findSaved(p);
    let nameInput = null;

    const actions = [];
    actions.push(h('button', { class: 'btn primary small', type: 'button', onclick: () => startNav(p) }, 'Navigate'));
    if (saved) {
      actions.push(h('button', { class: 'btn small danger', type: 'button', onclick: () => { deleteSaved(saved.id); closeCard(); } }, 'Remove from saved'));
    } else {
      if (p.cat === 'pin') nameInput = h('input', { type: 'text', maxlength: '80', value: p.name === 'Dropped pin' ? '' : p.name, placeholder: 'Name this place (e.g. Hotel, Car park)', 'aria-label': 'Place name' });
      actions.push(h('button', { class: 'btn small', type: 'button', onclick: () => {
        const name = nameInput ? (nameInput.value.trim() || 'My pin') : p.name;
        addSaved({ name, lat: p.lat, lng: p.lng, note: p.area || '' });
        closeCard();
      } }, 'Save place'));
    }
    actions.push(h('button', { class: 'btn small', type: 'button', onclick: () => copyLink(p) }, 'Copy link'));

    card.replaceChildren(...[
      h('button', { class: 'x', type: 'button', 'aria-label': 'Close', onclick: closeCard }, icon('close')),
      h('h3', {}, p.name),
      p.ar ? h('div', { class: 'meta', dir: 'rtl', lang: 'ar' }, p.ar) : null,
      h('div', { class: 'meta' }, [cat.label, p.area].filter(Boolean).join(' · ')),
      h('div', { class: 'meta' }, `${p.lat.toFixed(5)}, ${p.lng.toFixed(5)}`),
      nameInput,
      h('div', { class: 'btn-row' }, actions)].filter(Boolean)); // replaceChildren(null) would insert the text "null"
    card.hidden = false;
  }

  function closeCard() {
    S.selected = null;
    if (S.map) { S.map.selected = null; S.map.invalidate(); }
    $('#card').hidden = true;
  }

  async function copyLink(p) {
    const url = `${location.origin}/#/map?ll=${p.lat.toFixed(6)},${p.lng.toFixed(6)}&n=${encodeURIComponent(p.name)}`;
    try { await navigator.clipboard.writeText(url); toast('Link copied. The other person needs an account to open it.'); }
    catch { toast(`${p.lat.toFixed(5)}, ${p.lng.toFixed(5)}`); }
  }

  /* ============================================================== navigation */
  async function loadRouter() {
    if (S.router) return S.router;
    if (S.routerLoading) return S.routerLoading;
    S.routerLoading = (async () => {
      try {
        const res = await fetch('/roads/graph.json');
        if (!res.ok) return null;
        S.router = Router.createRouter(await res.json());
        return S.router;
      } catch { return null; } finally { S.routerLoading = null; }
    })();
    return S.routerLoading;
  }

  function startNav(p) {
    S.nav = { target: { id: p.id, name: p.name, lat: p.lat, lng: p.lng }, route: null, status: 'idle', lastReroute: 0, fitted: false, busy: false };
    if (S.map) { S.map.target = S.nav.target; S.map.route = null; S.map.invalidate(); }
    closeCard();
    enableCompass();
    startLocation(false);
    if (S.me) computeRoute();
    updateNavUI();
  }

  function stopNav() {
    S.nav = null;
    if (S.map) { S.map.target = null; S.map.route = null; S.map.invalidate(); }
    if (S.watchId != null) { navigator.geolocation.clearWatch(S.watchId); S.watchId = null; }
    S.me = null;
    if (S.map) S.map.me = null;
    $('#stepsList').hidden = true;
    updateNavUI();
  }

  async function computeRoute(reroute) {
    const n = S.nav;
    if (!n || !S.me || n.busy) return;
    n.busy = true; n.lastReroute = Date.now();
    if (!reroute) { n.status = 'routing'; updateNavUI(); }
    const router = await loadRouter();
    await new Promise((r) => setTimeout(r, 0)); // let the "calculating" state paint
    n.busy = false;
    if (S.nav !== n || !S.me) return;
    if (!router) { n.status = 'noroads'; n.route = null; }
    else {
      const r = router.route([S.me.lat, S.me.lng], [n.target.lat, n.target.lng]);
      if (r.error) { n.status = 'noroute'; n.route = null; }
      else {
        n.route = r; n.status = 'ok'; n.loc = Router.locate(r, S.me.lat, S.me.lng);
        if (reroute) toast('Route updated');
      }
    }
    if (S.map) {
      S.map.route = n.route ? n.route.coords : null;
      if (n.route && !n.fitted) { n.fitted = true; S.map.fitPoints(n.route.coords); }
      S.map.invalidate();
    }
    renderSteps();
    updateNavUI();
  }

  // called on every GPS fix while navigating
  function navTick() {
    const n = S.nav;
    if (!n || !S.me) return;
    if (n.status === 'idle') { computeRoute(); return; }
    if (n.status === 'ok') {
      n.loc = Router.locate(n.route, S.me.lat, S.me.lng);
      if (n.loc.off > Math.max(60, (S.me.acc || 0) * 1.5)) {
        const wait = 6000 - (Date.now() - n.lastReroute);
        if (wait <= 0) { computeRoute(true); return; }
        // too soon after the last calculation: check again as soon as it is allowed, even without a new GPS fix
        clearTimeout(n.timer); n.timer = setTimeout(navTick, wait + 50);
      }
    } else if (n.status === 'noroute' && Date.now() - n.lastReroute > 15000) { computeRoute(); return; }
    updateNavUI();
  }

  function startLocation(follow) {
    if (!navigator.geolocation) { toast('This device does not support location.'); return; }
    if (S.watchId != null) { if (follow && S.me && S.map) S.map.flyTo(S.me.lat, S.me.lng, Math.max(S.map.zoom, 15)); return; }
    let first = true;
    S.watchId = navigator.geolocation.watchPosition((pos) => {
      const c = pos.coords;
      S.me = { lat: c.latitude, lng: c.longitude, acc: c.accuracy };
      if (c.heading != null && !Number.isNaN(c.heading) && (c.speed || 0) > 1) S.gpsHeading = c.heading;
      if (S.map) { S.map.me = S.me; S.map.invalidate(); }
      if (first && S.map) {
        first = false;
        if (follow) S.map.flyTo(S.me.lat, S.me.lng, Math.max(S.map.zoom, 15));
      }
      if (S.nav) navTick();
    }, (err) => {
      S.watchId = null;
      toast(err.code === 1 ? 'Location permission was denied. Allow it in your browser settings.' : 'Could not get your location. GPS may be weak here.');
    }, { enableHighAccuracy: true, maximumAge: 2000, timeout: 25000 });
  }

  function enableCompass() {
    const handler = (e) => {
      const hd = typeof e.webkitCompassHeading === 'number' ? e.webkitCompassHeading : (e.absolute || e.type === 'deviceorientationabsolute') && e.alpha != null ? (360 - e.alpha) % 360 : null;
      if (hd != null) { S.compass = hd; updateNavUI(); }
    };
    if (S.compassOn) return;
    S.compassOn = true;
    const go = () => {
      window.addEventListener('deviceorientationabsolute', handler, true);
      window.addEventListener('deviceorientation', handler, true);
    };
    if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
      DeviceOrientationEvent.requestPermission().then((r) => { if (r === 'granted') go(); else S.compassOn = false; }).catch(() => { S.compassOn = false; });
    } else go();
  }

  function renderSteps() {
    const box = $('#stepsList');
    const n = S.nav;
    if (!n || !n.route) { box.replaceChildren(); return; }
    box.replaceChildren(...n.route.steps.map((s, i, all) => h('div', { class: 'step' },
      h('b', {}, s.text),
      h('span', {}, i < all.length - 1 ? fmtDist(all[i + 1].at - s.at) : ''))));
  }

  function updateNavUI() {
    const panel = $('#navpanel');
    if (!S.nav) { panel.hidden = true; return; }
    panel.hidden = false;
    const n = S.nav, t = n.target;
    const showSteps = n.status === 'ok';
    $('#navSteps').hidden = !showSteps;
    if (!showSteps) $('#stepsList').hidden = true;
    $('#navDest').textContent = 'To ' + t.name;
    $('#navTitle').textContent = t.name;
    if (!S.me) { $('#navDist').textContent = '...'; $('#navSub').textContent = 'Finding your location'; return; }
    if (n.status === 'idle' || n.status === 'routing') { $('#navDist').textContent = '...'; $('#navSub').textContent = 'Calculating the route'; return; }
    const heading = S.compass != null ? S.compass : S.gpsHeading != null ? S.gpsHeading : null;

    if (n.status === 'ok') {
      const r = n.route, loc = n.loc || Router.locate(r, S.me.lat, S.me.lng);
      const remaining = Math.max(0, r.distance - loc.along);
      if (remaining < 30) { $('#navTitle').textContent = 'You have arrived'; $('#navDist').textContent = ''; $('#navSub').textContent = t.name; return; }
      const next = r.steps.find((s) => s.at > loc.along + 8) || r.steps[r.steps.length - 1];
      const secs = r.duration * (remaining / r.distance);
      const eta = new Date(Date.now() + secs * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      $('#navTitle').textContent = next.text;
      $('#navDist').textContent = fmtDist(Math.max(0, next.at - loc.along));
      $('#navSub').textContent = [`${fmtDist(remaining)} left`, fmtDur(secs / 60), eta].map((x) => x.replace(/ /g, '\u00a0')).join(' · ');
      const ahead = Router.pointAlong(r, Math.min(r.distance, loc.along + 40));
      const brg = bearing(S.me, { lat: ahead[0], lng: ahead[1] });
      $('#navArrow').style.transform = `rotate(${heading != null ? brg - heading : brg}deg)`;
      return;
    }

    // no road route available: straight-line guidance
    const d = haversine(S.me, t);
    const brg = bearing(S.me, t);
    $('#navArrow').style.transform = `rotate(${(heading != null ? brg - heading : brg)}deg)`;
    if (d < 30) { $('#navDist').textContent = 'Arrived'; $('#navSub').textContent = ''; return; }
    $('#navDist').textContent = fmtDist(d);
    const why = n.status === 'noroads' ? 'No road data - straight line' : 'No road route found - straight line';
    $('#navSub').textContent = `${why} · ${compassPoint(brg)}${heading == null ? ' · arrow points from north' : ''}`;
  }

  /* ========================================================== saved places */
  const qKey = () => uk('queue');
  const persistSaved = () => store.set(uk('saved'), S.saved);

  function addSaved({ name, lat, lng, note }) {
    const tmp = 'tmp-' + Date.now() + Math.random().toString(36).slice(2, 6);
    S.saved.unshift({ id: tmp, name, lat, lng, note: note || '', created_at: Date.now() });
    persistSaved();
    const q = store.get(qKey(), []);
    q.push({ type: 'add', tmp, name, lat, lng, note: note || '' });
    store.set(qKey(), q);
    refreshAfterSavedChange();
    toast(navigator.onLine ? 'Saved' : 'Saved on this device. It will sync when you are online.');
    flushQueue();
  }

  function deleteSaved(id) {
    S.saved = S.saved.filter((s) => s.id !== id);
    persistSaved();
    let q = store.get(qKey(), []);
    if (typeof id === 'string' && id.startsWith('tmp-')) q = q.filter((op) => op.tmp !== id);
    else q.push({ type: 'del', id });
    store.set(qKey(), q);
    refreshAfterSavedChange();
    flushQueue();
  }

  function refreshAfterSavedChange() {
    refreshMarkers();
    if (S.selected) renderCard();
    rerenderIfView('saved');
    rerenderIfView('dashboard');
  }

  async function flushQueue() {
    if (!S.user || S.flushing || !navigator.onLine) return;
    S.flushing = true;
    try {
      const q = store.get(qKey(), []);
      while (q.length) {
        const op = q[0];
        try {
          if (op.type === 'add') {
            const r = await api('/api/saved', { method: 'POST', body: { name: op.name, lat: op.lat, lng: op.lng, note: op.note } });
            const it = S.saved.find((s) => s.id === op.tmp);
            if (it) it.id = r.saved.id;
          } else if (op.type === 'del') {
            await api('/api/saved/' + op.id, { method: 'DELETE' });
          }
        } catch (e) {
          if (e.status === 401) { sessionExpired(); return; }
          if (e instanceof NetError || (e.status && e.status >= 500)) return; // try again later
          // other 4xx: the server rejected this change; drop it
        }
        q.shift();
        store.set(qKey(), q);
        persistSaved();
      }
      try { S.saved = (await api('/api/saved')).saved; persistSaved(); } catch (e) { if (e.status === 401) sessionExpired(); }
    } finally {
      S.flushing = false;
      refreshAfterSavedChange();
    }
  }

  function renderSaved() {
    const root = $('#v-saved');
    const rows = S.saved.map((s) => h('div', { class: 'item' },
      h('span', { class: 'r-dot' }),
      h('div', { class: 'grow' }, h('b', {}, s.name), h('span', {}, [s.note, `${s.lat.toFixed(5)}, ${s.lng.toFixed(5)}`].filter(Boolean).join(' · '))),
      h('button', { class: 'btn small', type: 'button', onclick: () => { S.pendingSelect = { id: 's' + s.id, savedId: s.id, cat: 'saved', name: s.name, area: s.note, lat: s.lat, lng: s.lng }; location.hash = '#/map'; } }, 'Show'),
      h('button', { class: 'btn small primary', type: 'button', onclick: () => { S.pendingSelect = { id: 's' + s.id, savedId: s.id, cat: 'saved', name: s.name, area: s.note, lat: s.lat, lng: s.lng }; S.startNavAfter = true; location.hash = '#/map'; } }, 'Navigate'),
      h('button', { class: 'btn small danger', type: 'button', 'aria-label': `Delete ${s.name}`, onclick: () => deleteSaved(s.id) }, icon('trash'))));
    rows.forEach((r) => { $('.r-dot', r).style.background = CATS.saved.color; });
    const pending = store.get(qKey(), []).length;
    root.replaceChildren(h('div', { class: 'wrap' },
      h('h2', { class: 'page-title' }, 'Saved places'),
      h('p', { class: 'page-sub' }, pending ? `${pending} change${pending > 1 ? 's' : ''} waiting to sync when you are online.` : 'Your places are stored on this device and synced to your account.'),
      rows.length ? h('div', { class: 'list' }, rows) : h('div', { class: 'empty' }, 'Nothing saved yet. Open the map, tap anywhere to drop a pin, or pick a place and choose "Save place".')));
  }

  /* =============================================================== dashboard */
  function greet() { const hr = new Date().getHours(); return hr < 12 ? 'Good morning' : hr < 18 ? 'Good afternoon' : 'Good evening'; }

  async function tileCacheCount() {
    if (!('caches' in window)) return 0;
    try { return (await (await caches.open('raah-tiles-v1')).keys()).length; } catch { return 0; }
  }

  function stat(k, v, s, cls) {
    return h('div', { class: 'stat' }, h('div', { class: 'k' }, k), h('div', { class: 'v ' + (cls || '') }, v), h('div', { class: 's' }, s));
  }

  function renderDashboard() {
    const root = $('#v-dashboard');
    const t = S.tiles;
    const first = (S.user.name.split(' ')[0] || S.user.name);
    const online = navigator.onLine;
    const cacheStat = stat('Tiles on this device', '...', 'Downloaded for offline use');

    const tileOk = t && t.installed && !t.vector;
    const recent = store.get(uk('recent'), []);

    root.replaceChildren(h('div', { class: 'wrap' },
      h('div', { class: 'hero' },
        h('h2', {}, `${greet()}, ${first}`),
        h('p', {}, 'Where do you want to go? Search any place, save it, and navigate even with no internet.'),
        h('div', { class: 'row' },
          h('button', { class: 'btn gold', type: 'button', onclick: () => $('#q').focus() }, icon('search'), 'Search a place'),
          h('a', { class: 'btn', href: '#/map' }, icon('map'), 'Open map'),
          h('a', { class: 'btn', href: '#/offline' }, icon('download'), 'Download for offline'),
          S.installEvent ? h('button', { class: 'btn', type: 'button', onclick: installApp }, 'Install app') : null)),
      h('div', { class: 'grid' },
        stat('Connection', online ? 'Online' : 'Offline', online ? 'Using internet right now' : 'Running from saved data', online ? 'ok' : 'warn'),
        stat('Map data', tileOk ? 'Ready' : t ? (t.vector ? 'Unsupported' : 'Missing') : 'Unknown',
          tileOk ? `${t.name} · zoom ${t.minzoom}-${t.maxzoom}` : t ? 'See the Offline page for setup' : 'Connect once to check', tileOk ? 'ok' : 'warn'),
        stat('Road routing', t && t.roads && t.roads.installed ? 'Ready' : t ? 'Not installed' : 'Unknown', t && t.roads && t.roads.installed ? 'Turn-by-turn directions' : 'Navigation shows a straight line', t && t.roads && t.roads.installed ? 'ok' : 'warn'),
        cacheStat,
        stat('Saved places', String(S.saved.length), 'Synced to your account'),
        stat('Places database', String(S.places.length), 'Searchable offline')),
      h('div', { class: 'section' }, h('h3', {}, 'Browse by category'),
        h('div', { class: 'chips' }, ['landmark', 'mall', 'transport', 'culture', 'leisure', 'health', 'hotel', 'district'].map((k) => {
          const chip = h('button', { class: 'chip', type: 'button', onclick: () => searchFor(CATS[k].kw.split(' ')[0]) }, h('i', {}), CATS[k].label);
          $('i', chip).style.background = CATS[k].color;
          return chip;
        }))),
      recent.length ? h('div', { class: 'section' }, h('h3', {}, 'Recent searches'),
        h('div', { class: 'list' }, recent.slice(0, 5).map((r) => h('div', { class: 'item' },
          h('div', { class: 'grow' }, h('b', {}, r.name), h('span', {}, [(CATS[r.cat] || CATS.pin).label, r.area].filter(Boolean).join(' · '))),
          h('button', { class: 'btn small', type: 'button', onclick: () => { S.pendingSelect = r; location.hash = '#/map'; } }, 'Show'))))) : null,
      S.saved.length ? h('div', { class: 'section' }, h('h3', {}, 'Saved places'),
        h('div', { class: 'list' }, S.saved.slice(0, 4).map((s) => h('div', { class: 'item' },
          h('div', { class: 'grow' }, h('b', {}, s.name), h('span', {}, s.note || `${s.lat.toFixed(4)}, ${s.lng.toFixed(4)}`)),
          h('a', { class: 'btn small', href: '#/saved' }, 'Open'))))) : null,
      S.user.role === 'admin' ? h('div', { class: 'section' }, h('h3', {}, 'Administration'),
        h('a', { class: 'btn', href: '#/admin' }, icon('users'), 'Manage users')) : null));

    tileCacheCount().then((n) => { $('.v', cacheStat).textContent = String(n); });
  }

  async function installApp() {
    if (!S.installEvent) return;
    S.installEvent.prompt();
    await S.installEvent.userChoice.catch(() => {});
    S.installEvent = null;
    rerenderIfView('dashboard'); rerenderIfView('offline');
  }

  /* ======================================================= offline downloads */
  const PRESETS = {
    dubai: { label: 'Dubai urban area (Jebel Ali to Mirdif)', b: { w: 54.95, s: 24.90, e: 55.55, n: 25.40 } },
    central: { label: 'Central Dubai (Downtown, Deira, Jumeirah)', b: { w: 55.20, s: 25.10, e: 55.40, n: 25.30 } },
    view: { label: 'Current map view' },
  };
  const AVG_TILE_BYTES = 18 * 1024;
  const MAX_TILES = 40000;

  const lngToX = (lng, z) => Math.floor((lng + 180) / 360 * 2 ** z);
  const latToY = (lat, z) => { const s = Math.sin(Math.max(-85.05, Math.min(85.05, lat)) * Math.PI / 180); return Math.floor((0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI)) * 2 ** z); };

  function tileRange(b, z) {
    const n = 2 ** z;
    return { x0: Math.max(0, lngToX(b.w, z)), x1: Math.min(n - 1, lngToX(b.e, z)), y0: Math.max(0, latToY(b.n, z)), y1: Math.min(n - 1, latToY(b.s, z)) };
  }
  function countTiles(b, minZ, maxZ) {
    let c = 0;
    for (let z = minZ; z <= maxZ; z++) { const r = tileRange(b, z); c += Math.max(0, r.x1 - r.x0 + 1) * Math.max(0, r.y1 - r.y0 + 1); }
    return c;
  }
  function listTiles(b, minZ, maxZ) {
    const out = [];
    for (let z = minZ; z <= maxZ; z++) {
      const r = tileRange(b, z);
      for (let y = r.y0; y <= r.y1; y++) for (let x = r.x0; x <= r.x1; x++) out.push([z, x, y]);
    }
    return out;
  }

  function dlBounds() {
    if (S.dl.preset === 'view') return S.map ? S.map.getBounds() : { w: 55.2, s: 25.1, e: 55.4, n: 25.3 };
    return PRESETS[S.dl.preset].b;
  }
  function dlZoomRange() {
    const t = S.tiles;
    const lo = Math.max(t && Number.isFinite(t.minzoom) ? t.minzoom : 0, 9);
    const hi = Math.min(S.dl.maxZ, t && Number.isFinite(t.maxzoom) ? t.maxzoom : S.dl.maxZ);
    return [Math.min(lo, hi), hi];
  }

  async function startDownload() {
    if (!navigator.serviceWorker || !navigator.serviceWorker.controller) {
      toast('Offline storage is not active yet. It needs HTTPS (or localhost) and one page reload.');
      return;
    }
    const b = dlBounds();
    const [lo, hi] = dlZoomRange();
    const tiles = listTiles(b, lo, hi);
    if (!tiles.length) return;
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
    const ctrl = new AbortController();
    const prog = { total: tiles.length, done: 0, ok: 0, missing: 0, failed: 0 };
    S.dl.running = true; S.dl.ctrl = ctrl; S.dl.progress = prog;
    renderOffline();
    let i = 0, authFail = false;
    const worker = async () => {
      while (i < tiles.length && !ctrl.signal.aborted && !authFail) {
        const [z, x, y] = tiles[i++];
        try {
          const r = await fetch(`/tiles/${z}/${x}/${y}`, { signal: ctrl.signal });
          if (r.ok) { await r.arrayBuffer(); prog.ok++; }
          else if (r.status === 404) prog.missing++;
          else if (r.status === 401) authFail = true;
          else prog.failed++;
        } catch { if (ctrl.signal.aborted) return; prog.failed++; }
        prog.done++;
        if (prog.done % 10 === 0 || prog.done === prog.total) updateDlProgress();
      }
    };
    await Promise.all(Array.from({ length: 6 }, worker));
    S.dl.running = false; S.dl.ctrl = null;
    if (authFail) return sessionExpired();
    toast(ctrl.signal.aborted ? 'Download cancelled. What was saved stays available offline.'
      : `Done. ${prog.ok} tiles saved${prog.failed ? `, ${prog.failed} failed (run it again to retry)` : ''}.`);
    renderOffline();
  }

  function updateDlProgress() {
    const p = S.dl.progress;
    if (!p) return;
    const bar = $('#dlBar > i'), txt = $('#dlText');
    if (bar) bar.style.width = `${Math.round(p.done / p.total * 100)}%`;
    if (txt) txt.textContent = `${p.done} of ${p.total} tiles (${p.ok} saved${p.missing ? `, ${p.missing} not in map file` : ''}${p.failed ? `, ${p.failed} failed` : ''})`;
  }

  async function downloadRoads() {
    toast('Downloading road data...');
    try {
      const res = await fetch('/roads/graph.json?fresh=1');
      if (!res.ok) throw new Error('bad status');
      S.router = Router.createRouter(await res.json());
      toast(`Road data saved (${S.router.stats.nodes.toLocaleString()} junctions). Routing now works offline.`);
    } catch { toast('Could not download road data. Check your connection and try again.'); }
    renderOffline();
  }

  async function clearRoads() {
    if (!confirm('Remove the saved road data from this device? Navigation will show a straight line until you download it again.')) return;
    await caches.delete('raah-roads-v1');
    S.router = null;
    toast('Road data removed from this device.');
    renderOffline();
  }

  async function clearTileCache() {
    if (!confirm('Delete all map tiles saved on this device? You can download them again later.')) return;
    await caches.delete('raah-tiles-v1');
    toast('Saved map tiles removed from this device.');
    renderOffline();
  }

  function renderOffline() {
    const root = $('#v-offline');
    const t = S.tiles;
    const controlled = !!(navigator.serviceWorker && navigator.serviceWorker.controller);
    const tileOk = t && t.installed && !t.vector;
    const b = dlBounds();
    const [lo, hi] = dlZoomRange();
    const count = countTiles(b, lo, hi);
    const tooMany = count > MAX_TILES;
    const maxAvail = Math.min(18, t && Number.isFinite(t.maxzoom) ? t.maxzoom : 17);
    const zOptions = []; for (let z = 12; z <= Math.max(12, maxAvail); z++) zOptions.push(z);
    if (S.dl.maxZ > zOptions[zOptions.length - 1]) S.dl.maxZ = zOptions[zOptions.length - 1];

    const presetSel = h('select', { id: 'dlPreset', 'aria-label': 'Area to download', onchange: (e) => { S.dl.preset = e.target.value; renderOffline(); } },
      Object.entries(PRESETS).map(([k, v]) => h('option', { value: k, selected: S.dl.preset === k }, v.label)));
    const zoomSel = h('select', { id: 'dlZoom', 'aria-label': 'Detail level', onchange: (e) => { S.dl.maxZ = +e.target.value; renderOffline(); } },
      zOptions.map((z) => h('option', { value: String(z), selected: S.dl.maxZ === z }, `Zoom ${z}${z <= 13 ? ' - overview' : z <= 15 ? ' - streets' : ' - buildings'}`)));

    const cacheInfo = h('dd', {}, '...');
    const storageInfo = h('dd', {}, '...');

    const prog = S.dl.progress;
    const dlPanel = h('div', { class: 'panel' },
      h('h3', {}, 'Download an area for offline use'),
      h('p', { class: 'page-sub' }, 'Do this once on Wi-Fi or a cheap connection. The tiles are saved on this device, so the map works anywhere afterwards.'),
      !tileOk ? h('p', { class: 'error' }, t && t.vector ? 'The map file on the server uses vector tiles, which are not supported yet.' : 'The server has no map tiles installed yet - see README.md.') : null,
      !controlled ? h('p', { class: 'error' }, 'Offline storage is not active yet. Reload the page once. On a phone it also needs HTTPS - plain http:// addresses on a network cannot store offline data.') : null,
      h('div', { class: 'field-row' }, h('label', {}, 'Area', presetSel), h('label', {}, 'Detail', zoomSel)),
      h('p', {}, `${count.toLocaleString()} tiles (zoom ${lo}-${hi}), about ${fmtBytes(count * AVG_TILE_BYTES)} - an estimate.`),
      tooMany ? h('p', { class: 'error' }, `That is more than ${MAX_TILES.toLocaleString()} tiles. Pick a smaller area or lower detail.`) : null,
      S.dl.running || prog ? h('div', {}, h('div', { class: 'bar', id: 'dlBar' }, h('i', {})), h('div', { id: 'dlText', class: 'muted' }, '')) : null,
      h('div', { class: 'btn-row' },
        S.dl.running
          ? h('button', { class: 'btn', type: 'button', onclick: () => S.dl.ctrl && S.dl.ctrl.abort() }, 'Cancel')
          : h('button', { class: 'btn primary', type: 'button', disabled: !tileOk || !controlled || tooMany || !navigator.onLine, onclick: startDownload }, icon('download'), 'Download area')));

    const info = h('div', { class: 'panel' },
      h('h3', {}, 'On this device'),
      h('dl', { class: 'kv' },
        h('dt', {}, 'Saved map tiles'), cacheInfo,
        h('dt', {}, 'Storage used'), storageInfo,
        h('dt', {}, 'Server map file'), h('dd', {}, tileOk ? `${t.name} (${t.format.toUpperCase()}, zoom ${t.minzoom}-${t.maxzoom}, ${fmtBytes(t.sizeBytes)})` : 'Not installed')),
      h('div', { class: 'btn-row' },
        h('button', { class: 'btn danger', type: 'button', onclick: clearTileCache }, icon('trash'), 'Remove saved tiles'),
        S.installEvent ? h('button', { class: 'btn', type: 'button', onclick: installApp }, 'Install app on this device') : null));

    const rd = t && t.roads;
    const roadInfo = h('dd', {}, '...');
    const roadsPanel = h('div', { class: 'panel' },
      h('h3', {}, 'Road data for turn-by-turn directions'),
      h('p', { class: 'page-sub' }, rd && rd.installed ? `Available on the server (${fmtBytes(rd.sizeBytes)}). Download it once and routing works with no internet.` : 'The server has no road data yet, so navigation shows a straight line. See README.md, section "Turn-by-turn routing".'),
      h('dl', { class: 'kv' }, h('dt', {}, 'Saved on this device'), roadInfo),
      h('p', { class: 'hint' }, 'Road data: (c) OpenStreetMap contributors, ODbL.'),
      h('div', { class: 'btn-row' },
        h('button', { class: 'btn primary', type: 'button', disabled: !(rd && rd.installed) || !controlled || !navigator.onLine, onclick: downloadRoads }, icon('download'), 'Download road data'),
        h('button', { class: 'btn danger', type: 'button', onclick: clearRoads }, icon('trash'), 'Remove')));
    caches.open('raah-roads-v1').then((c) => c.match('/roads/graph.json')).then((m) => { roadInfo.textContent = m ? 'Yes - routing works offline' : 'No'; }).catch(() => { roadInfo.textContent = 'Unknown'; });

    root.replaceChildren(h('div', { class: 'wrap' },
      h('h2', { class: 'page-title' }, 'Offline maps'),
      h('p', { class: 'page-sub' }, 'Tiles you view on the map are also kept automatically, so places you have visited online stay available.'),
      dlPanel, roadsPanel, info));

    updateDlProgress();
    tileCacheCount().then((n) => { cacheInfo.textContent = `${n.toLocaleString()} tiles`; });
    if (navigator.storage && navigator.storage.estimate) {
      navigator.storage.estimate().then((e) => { storageInfo.textContent = `${fmtBytes(e.usage)} of ${fmtBytes(e.quota)} available`; }).catch(() => { storageInfo.textContent = 'Unknown'; });
    } else storageInfo.textContent = 'Unknown';
  }

  /* ===================================================================== admin */
  async function renderAdmin() {
    const root = $('#v-admin');
    root.replaceChildren(h('div', { class: 'wrap' }, h('h2', { class: 'page-title' }, 'Users'), h('p', { class: 'page-sub' }, 'Loading...')));
    let users;
    try { users = (await api('/api/admin/users')).users; }
    catch (e) {
      root.replaceChildren(h('div', { class: 'wrap' }, h('h2', { class: 'page-title' }, 'Users'),
        h('div', { class: 'empty' }, e instanceof NetError ? 'You are offline. User management needs a connection.' : e.message)));
      return;
    }
    const rows = users.map((u) => h('tr', {},
      h('td', {}, u.name),
      h('td', {}, u.email),
      h('td', {}, h('span', { class: 'tag ' + (u.role === 'admin' ? 'admin' : '') }, u.role)),
      h('td', {}, new Date(u.created_at).toLocaleDateString()),
      h('td', {}, String(u.saved)),
      h('td', {}, u.id === S.user.id ? '' : h('button', { class: 'btn small danger', type: 'button', onclick: async () => {
        if (!confirm(`Delete ${u.name} (${u.email}) and all their saved places?`)) return;
        try { await api('/api/admin/users/' + u.id, { method: 'DELETE' }); toast('User deleted'); renderAdmin(); } catch (e) { toast(e.message); }
      } }, 'Delete'))));
    root.replaceChildren(h('div', { class: 'wrap' },
      h('h2', { class: 'page-title' }, 'Users'),
      h('p', { class: 'page-sub' }, `${users.length} account${users.length === 1 ? '' : 's'}. Set ALLOW_REGISTRATION=0 on the server to stop new sign-ups.`),
      h('table', { class: 'tbl' },
        h('thead', {}, h('tr', {}, ['Name', 'Email', 'Role', 'Joined', 'Saved', ''].map((c) => h('th', {}, c)))),
        h('tbody', {}, rows))));
  }

  /* ==================================================================== boot */
  function bindStatic() {
    $('#tabLogin').addEventListener('click', () => setAuthTab('login'));
    $('#tabRegister').addEventListener('click', () => setAuthTab('register'));
    $('#loginForm').addEventListener('submit', (e) => { e.preventDefault(); submitAuth(e.target, '/api/login'); });
    $('#registerForm').addEventListener('submit', (e) => { e.preventDefault(); submitAuth(e.target, '/api/register'); });
    $('#logoutBtn').addEventListener('click', logout);
    $('#userBtn').addEventListener('click', () => {
      const m = $('#userMenu');
      m.hidden = !m.hidden;
      $('#userBtn').setAttribute('aria-expanded', String(!m.hidden));
    });
    document.addEventListener('click', (e) => { if (!e.target.closest('.usermenu')) $('#userMenu').hidden = true; });
    $('#zoomIn').addEventListener('click', () => S.map && S.map.zoomBy(1));
    $('#zoomOut').addEventListener('click', () => S.map && S.map.zoomBy(-1));
    $('#locateBtn').addEventListener('click', () => startLocation(true));
    $('#navStop').addEventListener('click', stopNav);
    $('#navSteps').addEventListener('click', () => { const l = $('#stepsList'); l.hidden = !l.hidden; $('#navSteps').setAttribute('aria-expanded', String(!l.hidden)); });
    bindSearch();
    // "Navigate" pressed from the Saved list: start once the map and card exist
    new MutationObserver(() => {
      if (S.startNavAfter && S.selected && currentView() === 'map') { S.startNavAfter = false; startNav(S.selected); }
    }).observe($('#card'), { childList: true });
  }

  async function boot() {
    registerSW();
    bindStatic();
    $$('[data-icon]').forEach((el) => { if (!el.dataset.done && !el.closest('#app')) { el.prepend(icon(el.dataset.icon)); el.dataset.done = '1'; } });
    const cfg = await api('/api/config').catch(() => null);
    try {
      const { user } = await api('/api/me');
      S.user = user;
      store.set('user', user);
      enterApp();
    } catch (e) {
      if (e instanceof NetError) {
        const cached = store.get('user', null);
        if (cached) { S.user = cached; enterApp(); return; }
      } else store.del('user');
      showAuth(cfg);
    }
  }

  boot();
})();
