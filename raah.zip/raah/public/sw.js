/* Raah service worker: makes the app and any viewed/downloaded map tiles work without internet. */
'use strict';

const SHELL = 'raah-shell-v2';
const ROADS = 'raah-roads-v1';
const TILES = 'raah-tiles-v1';
const SHELL_FILES = [
  '/', '/index.html', '/style.css', '/app.js', '/map.js', '/router.js', '/manifest.webmanifest',
  '/icon.svg', '/icon-192.png', '/icon-512.png', '/data/places.json',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(SHELL).then((c) => c.addAll(SHELL_FILES)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) {
      if (key.startsWith('raah-shell-') && key !== SHELL) await caches.delete(key);
    }
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api/')) return; // never cache account data

  if (url.pathname.startsWith('/tiles/')) {
    event.respondWith(tile(req));
  } else if (url.pathname === '/roads/graph.json') {
    event.respondWith(roads(req));
  } else if (req.mode === 'navigate') {
    event.respondWith(staleWhileRevalidate(req, '/index.html'));
  } else {
    event.respondWith(staleWhileRevalidate(req, req));
  }
});

// Map tiles: cache-first, so tiles you have seen or downloaded never cost data again.
async function tile(req) {
  const cache = await caches.open(TILES);
  const hit = await cache.match(req);
  if (hit) return hit;
  try {
    const res = await fetch(req);
    if (res.ok) cache.put(req, res.clone());
    return res;
  } catch {
    return new Response('', { status: 504 });
  }
}

// Road network: saved copy first (it is large), refreshed when the Offline page asks for it with ?fresh=1
async function roads(req) {
  const cache = await caches.open(ROADS);
  const fresh = new URL(req.url).searchParams.has('fresh');
  const key = new Request(new URL(req.url).origin + '/roads/graph.json');
  if (!fresh) { const hit = await cache.match(key); if (hit) return hit; }
  try {
    const res = await fetch(key);
    if (res.ok) { await cache.put(key, res.clone()); }
    return res;
  } catch {
    return (await cache.match(key)) || new Response('', { status: 504 });
  }
}

// App files: show the saved copy immediately (fast on slow/expensive connections), refresh it in the background.
async function staleWhileRevalidate(req, key) {
  const cache = await caches.open(SHELL);
  const hit = await cache.match(key);
  const network = fetch(req)
    .then((res) => { if (res.ok) cache.put(key, res.clone()); return res; })
    .catch(() => null);
  return hit || (await network) || new Response('You are offline and this page has not been saved yet.', { status: 504 });
}
