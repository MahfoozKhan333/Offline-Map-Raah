#!/usr/bin/env node
'use strict';
/*
 * Converts an OpenStreetMap XML file (.osm) into the compact road graph Raah uses for offline routing.
 *
 *   node tools/build-graph.js dubai.osm data/roads.json.gz
 *
 * Input: OSM XML, one element per line (what osmium, Overpass and BBBike produce).
 *   PBF files must be converted first:  osmium cat dubai.osm.pbf -o dubai.osm
 * Output: gzipped JSON. Drive-able roads only; junction-to-junction edges keep their curve shape.
 * Data (c) OpenStreetMap contributors, ODbL.
 */
const fs = require('node:fs');
const zlib = require('node:zlib');
const readline = require('node:readline');

const [input, output = 'data/roads.json.gz'] = process.argv.slice(2);
if (!input) { console.error('Usage: node tools/build-graph.js input.osm [output.json.gz]'); process.exit(1); }

const SPEED = { motorway: 100, motorway_link: 60, trunk: 90, trunk_link: 55, primary: 70, primary_link: 45, secondary: 60,
  secondary_link: 40, tertiary: 50, tertiary_link: 35, unclassified: 45, residential: 35, living_street: 20, service: 20, road: 40 };
const R = 6371008.8, RAD = Math.PI / 180;
const hav = (a, b, c, d) => { const dl = (c - a) * RAD, dg = (d - b) * RAD; const x = Math.sin(dl / 2) ** 2 + Math.cos(a * RAD) * Math.cos(c * RAD) * Math.sin(dg / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(x)); };
const attr = (line, name) => { const m = new RegExp(`\\b${name}="([^"]*)"`).exec(line); return m ? m[1] : null; };
const unesc = (s) => s.replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');

function lines(file) { return readline.createInterface({ input: fs.createReadStream(file), crlfDelay: Infinity }); }

function accept(tags) {
  const hw = tags.highway;
  if (!hw || !(hw in SPEED)) return null;
  if (['no', 'private'].includes(tags.access) && !['yes', 'permissive'].includes(tags.motor_vehicle)) return null;
  if (tags.motor_vehicle === 'no' || tags.motorcar === 'no' || tags.vehicle === 'no') return null;
  if (tags.area === 'yes') return null;
  let speed = SPEED[hw];
  const ms = /^(\d+)\s*(mph)?$/.exec(tags.maxspeed || '');
  if (ms) speed = Math.round(+ms[1] * (ms[2] ? 1.609 : 1)) * 0.9; // real-world average is a bit below the limit
  if (hw === 'service' && ['parking_aisle', 'driveway'].includes(tags.service)) speed = 12;
  let oneway = 0; // 0 two-way, 1 forward, -1 backward
  const ow = tags.oneway;
  if (ow === 'yes' || ow === '1' || ow === 'true') oneway = 1;
  else if (ow === '-1') oneway = -1;
  else if (tags.junction === 'roundabout' || hw === 'motorway' || hw === 'motorway_link') oneway = ow === 'no' ? 0 : 1;
  return { speed: Math.max(5, Math.round(speed)), oneway, name: tags.name || tags.ref || '' };
}

async function main() {
  // pass 1: ways
  const ways = [];
  const use = new Map();
  let cur = null;
  for await (const raw of lines(input)) {
    const line = raw.trim();
    if (line.startsWith('<way ')) { cur = { nodes: [], tags: {} }; if (line.endsWith('/>')) cur = null; }
    else if (cur && line.startsWith('<nd ')) cur.nodes.push(attr(line, 'ref'));
    else if (cur && line.startsWith('<tag ')) cur.tags[unesc(attr(line, 'k'))] = unesc(attr(line, 'v') || '');
    else if (cur && line.startsWith('</way>')) {
      const a = accept(cur.tags);
      if (a && cur.nodes.length > 1) {
        ways.push({ nodes: cur.nodes, ...a });
        cur.nodes.forEach((id, i) => use.set(id, (use.get(id) || 0) + (i === 0 || i === cur.nodes.length - 1 ? 2 : 1)));
      }
      cur = null;
    }
  }
  console.log(`ways: ${ways.length}, nodes used: ${use.size}`);

  // pass 2: coordinates of used nodes
  const pos = new Map();
  for await (const raw of lines(input)) {
    if (!raw.includes('<node ')) continue;
    const line = raw.trim();
    const id = attr(line, 'id');
    if (!use.has(id)) continue;
    pos.set(id, [Math.round(+attr(line, 'lat') * 1e6), Math.round(+attr(line, 'lon') * 1e6)]);
  }

  // build junction graph
  const nodeIndex = new Map(), nodes = [];
  const jid = (osmId) => {
    let i = nodeIndex.get(osmId);
    if (i === undefined) { i = nodes.length / 2; nodeIndex.set(osmId, i); const p = pos.get(osmId); nodes.push(p[0], p[1]); }
    return i;
  };
  const names = [''], nameIdx = new Map([['', 0]]);
  const nameId = (n) => { let i = nameIdx.get(n); if (i === undefined) { i = names.length; names.push(n); nameIdx.set(n, i); } return i; };
  const edges = [], shape = [];

  for (const w of ways) {
    const ids = w.nodes.filter((id) => pos.has(id));
    if (ids.length < 2) continue;
    const nm = nameId(unesc(w.name));
    let i = 0;
    for (let j = 1; j < ids.length; j++) {
      const isJ = use.get(ids[j]) > 1 || j === ids.length - 1;
      if (!isJ) continue;
      const inter = [];
      let len = 0, prev = pos.get(ids[i]);
      for (let k = i + 1; k <= j; k++) {
        const p = pos.get(ids[k]);
        len += hav(prev[0] / 1e6, prev[1] / 1e6, p[0] / 1e6, p[1] / 1e6);
        prev = p;
        if (k < j) inter.push(p);
      }
      const a = jid(ids[i]), b = jid(ids[j]);
      if (a !== b || inter.length > 1) {
        // shape points are stored in TRAVEL order; flags bit 1 marks the copy used for snapping
        if (w.oneway >= 0) edges.push(a, b, Math.max(1, Math.round(len)), w.speed, nm, shape.length / 2, inter.length, 2), inter.forEach((p) => shape.push(p[0], p[1]));
        if (w.oneway <= 0) {
          const rv = inter.slice().reverse();
          edges.push(b, a, Math.max(1, Math.round(len)), w.speed, nm, shape.length / 2, rv.length, w.oneway === 0 ? 0 : 2);
          rv.forEach((p) => shape.push(p[0], p[1]));
        }
      }
      i = j;
    }
  }

  // keep only the largest connected component so snapping never lands on an isolated fragment
  const n = nodes.length / 2, ne = edges.length / 8, parent = Int32Array.from({ length: n }, (_, k) => k);
  const find = (x) => { while (parent[x] !== x) { parent[x] = parent[parent[x]]; x = parent[x]; } return x; };
  for (let e = 0; e < ne; e++) { const a = find(edges[e * 8]), b = find(edges[e * 8 + 1]); if (a !== b) parent[a] = b; }
  const size = new Map(); for (let k = 0; k < n; k++) size.set(find(k), (size.get(find(k)) || 0) + 1);
  let best = -1, bestSize = 0; for (const [r, s] of size) if (s > bestSize) { best = r; bestSize = s; }
  const remap = new Int32Array(n).fill(-1); const nn = []; let c = 0;
  for (let k = 0; k < n; k++) if (find(k) === best) { remap[k] = c++; nn.push(nodes[2 * k], nodes[2 * k + 1]); }
  const ee = [];
  for (let e = 0; e < ne; e++) { const f = remap[edges[e * 8]]; if (f < 0) continue; const o = edges.slice(e * 8, e * 8 + 8); o[0] = f; o[1] = remap[o[1]]; ee.push(...o); }

  // drop names that belong only to removed fragments
  const keep = new Map([[0, 0]]), names2 = [''];
  for (let e = 0; e < ee.length; e += 8) { const o = ee[e + 4]; if (!keep.has(o)) { keep.set(o, names2.length); names2.push(names[o]); } ee[e + 4] = keep.get(o); }

  let minLat = 1e9, maxLat = -1e9, minLng = 1e9, maxLng = -1e9;
  for (let k = 0; k < nn.length; k += 2) { minLat = Math.min(minLat, nn[k]); maxLat = Math.max(maxLat, nn[k]); minLng = Math.min(minLng, nn[k + 1]); maxLng = Math.max(maxLng, nn[k + 1]); }
  const graph = { v: 1, attribution: '(c) OpenStreetMap contributors (ODbL)', bounds: [minLng / 1e6, minLat / 1e6, maxLng / 1e6, maxLat / 1e6], names: names2, nodes: nn, edges: ee, shape };
  const json = Buffer.from(JSON.stringify(graph));
  fs.mkdirSync(require('node:path').dirname(require('node:path').resolve(output)), { recursive: true });
  fs.writeFileSync(output, output.endsWith('.gz') ? zlib.gzipSync(json, { level: 9 }) : json);
  console.log(`junctions: ${nn.length / 2}, directed edges: ${ee.length / 8}, size: ${(fs.statSync(output).size / 1048576).toFixed(1)} MB -> ${output}`);
}
main().catch((e) => { console.error(e); process.exit(1); });
