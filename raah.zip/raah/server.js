'use strict';
/*
 * Raah — offline-first maps server.
 * Zero dependencies. Requires Node.js >= 22.12 (uses the built-in node:sqlite).
 *
 * Serves: the web app (public/), JSON API (auth + saved places),
 * and map tiles from an MBTiles file or a tiles/{z}/{x}/{y}.png folder.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const os = require('node:os');
const { promisify } = require('node:util');
const { DatabaseSync } = require('node:sqlite');

const scrypt = promisify(crypto.scrypt);

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(ROOT, 'data'));
const ALLOW_REGISTRATION = process.env.ALLOW_REGISTRATION !== '0';
const COOKIE_SECURE = process.env.COOKIE_SECURE === '1';
const TRUST_PROXY = process.env.TRUST_PROXY === '1';
const SESSION_MS = 30 * 24 * 3600 * 1000;
const MAX_SAVED_PER_USER = 500;

fs.mkdirSync(DATA_DIR, { recursive: true });

/* ------------------------------------------------------------------ DB */
const db = new DatabaseSync(path.join(DATA_DIR, 'app.db'));
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    pass TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS saved (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    lat REAL NOT NULL,
    lng REAL NOT NULL,
    note TEXT NOT NULL DEFAULT '',
    created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS saved_user ON saved(user_id);
`);

const q = {
  userCount: db.prepare('SELECT COUNT(*) AS c FROM users'),
  userByEmail: db.prepare('SELECT * FROM users WHERE email = ?'),
  insertUser: db.prepare('INSERT INTO users (name, email, pass, role, created_at) VALUES (?, ?, ?, ?, ?)'),
  insertSession: db.prepare('INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)'),
  sessionUser: db.prepare(`SELECT u.id, u.name, u.email, u.role FROM sessions s
                           JOIN users u ON u.id = s.user_id WHERE s.token = ? AND s.expires_at > ?`),
  deleteSession: db.prepare('DELETE FROM sessions WHERE token = ?'),
  purgeSessions: db.prepare('DELETE FROM sessions WHERE expires_at < ?'),
  savedList: db.prepare('SELECT id, name, lat, lng, note, created_at FROM saved WHERE user_id = ? ORDER BY id DESC'),
  savedCount: db.prepare('SELECT COUNT(*) AS c FROM saved WHERE user_id = ?'),
  savedInsert: db.prepare('INSERT INTO saved (user_id, name, lat, lng, note, created_at) VALUES (?, ?, ?, ?, ?, ?)'),
  savedDelete: db.prepare('DELETE FROM saved WHERE id = ? AND user_id = ?'),
  adminUsers: db.prepare(`SELECT u.id, u.name, u.email, u.role, u.created_at,
                          (SELECT COUNT(*) FROM saved WHERE user_id = u.id) AS saved
                          FROM users u ORDER BY u.id`),
  userDelete: db.prepare('DELETE FROM users WHERE id = ?'),
};

q.purgeSessions.run(Date.now());
setInterval(() => q.purgeSessions.run(Date.now()), 3600 * 1000).unref();

/* ---------------------------------------------------------------- Tiles */
const TILE_DIR = path.join(DATA_DIR, 'tiles');
let mb = null; // { stmt, meta, file, size }
let folderInfo = null; // { minzoom, maxzoom }

function openTiles() {
  let file = process.env.MBTILES ? path.resolve(process.env.MBTILES) : null;
  if (!file) {
    const found = fs.readdirSync(DATA_DIR).filter((f) => f.endsWith('.mbtiles')).sort()[0];
    if (found) file = path.join(DATA_DIR, found);
  }
  if (file && fs.existsSync(file)) {
    try {
      const tdb = new DatabaseSync(file, { readOnly: true });
      let meta = {};
      try {
        meta = Object.fromEntries(tdb.prepare('SELECT name, value FROM metadata').all().map((r) => [r.name, r.value]));
      } catch { /* metadata table is optional */ }
      if (meta.minzoom == null || meta.maxzoom == null) {
        const r = tdb.prepare('SELECT MIN(zoom_level) AS a, MAX(zoom_level) AS b FROM tiles').get();
        meta.minzoom = meta.minzoom ?? r.a;
        meta.maxzoom = meta.maxzoom ?? r.b;
      }
      mb = {
        file,
        meta,
        size: fs.statSync(file).size,
        stmt: tdb.prepare('SELECT tile_data FROM tiles WHERE zoom_level = ? AND tile_column = ? AND tile_row = ?'),
      };
      return;
    } catch (e) {
      console.error('Could not open MBTiles file', file, '-', e.message);
    }
  }
  if (fs.existsSync(TILE_DIR)) {
    const zs = fs.readdirSync(TILE_DIR).filter((d) => /^\d+$/.test(d)).map(Number).sort((a, b) => a - b);
    if (zs.length) folderInfo = { minzoom: zs[0], maxzoom: zs[zs.length - 1] };
  }
}
openTiles();

function sniff(buf) {
  if (buf[0] === 0x89 && buf[1] === 0x50) return 'image/png';
  if (buf[0] === 0xff && buf[1] === 0xd8) return 'image/jpeg';
  if (buf.length > 12 && buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WEBP') return 'image/webp';
  if (buf[0] === 0x1f && buf[1] === 0x8b) return 'vector'; // gzipped protobuf (vector tiles)
  return 'application/octet-stream';
}

function getTile(z, x, y) {
  if (mb) {
    const row = mb.stmt.get(z, x, (1 << z) - 1 - y); // MBTiles uses TMS rows
    if (!row) return null;
    const data = Buffer.from(row.tile_data);
    return { data, type: sniff(data) };
  }
  if (folderInfo) {
    for (const [ext, type] of [['png', 'image/png'], ['jpg', 'image/jpeg'], ['webp', 'image/webp']]) {
      const f = path.join(TILE_DIR, String(z), String(x), `${y}.${ext}`);
      try { return { data: fs.readFileSync(f), type }; } catch { /* try next */ }
    }
  }
  return null;
}

function tileStatus() {
  if (mb) {
    const m = mb.meta;
    const fmt = (m.format || '').toLowerCase();
    const bounds = (m.bounds || '').split(',').map(Number);
    const center = (m.center || '').split(',').map(Number);
    return {
      installed: true,
      mode: 'mbtiles',
      name: m.name || path.basename(mb.file),
      format: fmt || 'png',
      vector: fmt === 'pbf' || fmt === 'mvt',
      minzoom: Number(m.minzoom),
      maxzoom: Number(m.maxzoom),
      bounds: bounds.length === 4 && bounds.every(Number.isFinite) ? bounds : null,
      center: center.length >= 2 && center.every(Number.isFinite) ? center : null,
      attribution: m.attribution || '',
      sizeBytes: mb.size,
    };
  }
  if (folderInfo) {
    return { installed: true, mode: 'folder', name: 'Tile folder', format: 'png', vector: false, ...folderInfo, bounds: null, center: null, attribution: '', sizeBytes: null };
  }
  return { installed: false };
}

/* ---------------------------------------------------------------- Roads */
// Road network for offline routing, built with tools/build-graph.js
function roadsFile() {
  for (const f of ['roads.json.gz', 'roads.json']) {
    const p = path.join(DATA_DIR, f);
    if (fs.existsSync(p)) return p;
  }
  return null;
}
function roadsStatus() {
  const f = roadsFile();
  if (!f) return { installed: false };
  return { installed: true, sizeBytes: fs.statSync(f).size, version: Math.floor(fs.statSync(f).mtimeMs) };
}
function roadsRoute(req, res) {
  if (!currentUser(req)) return json(res, 401, { error: 'Not signed in' });
  const f = roadsFile();
  if (!f) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('No road data installed'); }
  const st = fs.statSync(f);
  const etag = `"${st.size}-${Math.floor(st.mtimeMs)}"`;
  if (req.headers['if-none-match'] === etag) { res.writeHead(304, { ETag: etag }); return res.end(); }
  const h = { 'Content-Type': 'application/json', 'Content-Length': st.size, ETag: etag, 'Cache-Control': 'private, no-cache' };
  if (f.endsWith('.gz')) h['Content-Encoding'] = 'gzip';
  res.writeHead(200, h);
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(f).pipe(res);
}

/* ----------------------------------------------------------- Utilities */
class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function setSecurityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(self), camera=(), microphone=()');
  res.setHeader('Content-Security-Policy',
    "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; " +
    "connect-src 'self'; worker-src 'self'; manifest-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
}

function json(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

function clientIp(req) {
  if (TRUST_PROXY) {
    const xff = req.headers['x-forwarded-for'];
    if (xff) return String(xff).split(',')[0].trim();
  }
  return req.socket.remoteAddress || 'unknown';
}

function isSecure(req) {
  return COOKIE_SECURE || (TRUST_PROXY && req.headers['x-forwarded-proto'] === 'https');
}

async function readJson(req) {
  const type = String(req.headers['content-type'] || '');
  if (!type.toLowerCase().includes('application/json')) throw new HttpError(415, 'Content-Type must be application/json');
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > 64 * 1024) throw new HttpError(413, 'Request too large');
    chunks.push(c);
  }
  let data;
  try { data = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); } catch { throw new HttpError(400, 'Invalid JSON'); }
  if (!data || typeof data !== 'object' || Array.isArray(data)) throw new HttpError(400, 'Invalid JSON body');
  return data;
}

const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now();
  let e = hits.get(key);
  if (!e || e.reset < now) { e = { n: 0, reset: now + windowMs }; hits.set(key, e); }
  e.n += 1;
  return e.n > max;
}
setInterval(() => { const n = Date.now(); for (const [k, e] of hits) if (e.reset < n) hits.delete(k); }, 60000).unref();

/* ---------------------------------------------------------------- Auth */
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const DUMMY_SALT = crypto.randomBytes(16);

async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const h = await scrypt(pw, salt, 64);
  return `${salt.toString('hex')}:${h.toString('hex')}`;
}
async function checkPassword(pw, stored) {
  if (!stored) { await scrypt(pw, DUMMY_SALT, 64); return false; } // equalise timing for unknown users
  const [s, h] = stored.split(':');
  const expected = Buffer.from(h, 'hex');
  const actual = await scrypt(pw, Buffer.from(s, 'hex'), 64);
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

function cookies(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i < 1) continue;
    try { out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); } catch { /* ignore bad cookie */ }
  }
  return out;
}

function currentUser(req) {
  const token = cookies(req).sid;
  if (!token) return null;
  return q.sessionUser.get(sha(token), Date.now()) || null;
}

function startSession(req, res, userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  q.insertSession.run(sha(token), userId, Date.now() + SESSION_MS);
  res.setHeader('Set-Cookie',
    `sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_MS / 1000}${isSecure(req) ? '; Secure' : ''}`);
}

function clearCookie(req, res) {
  res.setHeader('Set-Cookie', `sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${isSecure(req) ? '; Secure' : ''}`);
}

const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, role: u.role });

function validEmail(e) { return typeof e === 'string' && e.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }

/* ----------------------------------------------------------------- API */
async function api(req, res, p) {
  const m = req.method;
  res.setHeader('Cache-Control', 'no-store');

  if (m === 'GET' && p === '/api/health') return json(res, 200, { ok: true });

  if (m === 'GET' && p === '/api/config') {
    const first = q.userCount.get().c === 0;
    return json(res, 200, { registration: ALLOW_REGISTRATION || first, firstUser: first });
  }

  if (m === 'POST' && p === '/api/register') {
    if (limited('reg:' + clientIp(req), 10, 3600 * 1000)) throw new HttpError(429, 'Too many attempts. Try again later.');
    const b = await readJson(req);
    const first = q.userCount.get().c === 0;
    if (!ALLOW_REGISTRATION && !first) throw new HttpError(403, 'Registration is closed. Ask the administrator for an account.');
    const name = typeof b.name === 'string' ? b.name.trim() : '';
    const email = typeof b.email === 'string' ? b.email.trim().toLowerCase() : '';
    const password = typeof b.password === 'string' ? b.password : '';
    if (!name || name.length > 60) throw new HttpError(400, 'Please enter your name (up to 60 characters).');
    if (!validEmail(email)) throw new HttpError(400, 'Please enter a valid email address.');
    if (password.length < 8 || password.length > 200) throw new HttpError(400, 'Password must be at least 8 characters.');
    const pass = await hashPassword(password);
    // Re-check after the async hash so two simultaneous first sign-ups cannot both become admin.
    const role = q.userCount.get().c === 0 ? 'admin' : 'user';
    let id;
    try {
      id = Number(q.insertUser.run(name, email, pass, role, Date.now()).lastInsertRowid);
    } catch (e) {
      if (String(e.message).includes('UNIQUE')) throw new HttpError(409, 'An account with this email already exists.');
      throw e;
    }
    startSession(req, res, id);
    return json(res, 201, { user: { id, name, email, role } });
  }

  if (m === 'POST' && p === '/api/login') {
    const ip = clientIp(req);
    if (limited('login-ip:' + ip, 30, 15 * 60 * 1000)) throw new HttpError(429, 'Too many attempts. Try again in a few minutes.');
    const b = await readJson(req);
    const email = typeof b.email === 'string' ? b.email.trim().toLowerCase() : '';
    const password = typeof b.password === 'string' ? b.password.slice(0, 200) : '';
    if (limited('login-email:' + email, 10, 15 * 60 * 1000)) throw new HttpError(429, 'Too many attempts. Try again in a few minutes.');
    const user = q.userByEmail.get(email);
    const ok = await checkPassword(password, user && user.pass);
    if (!user || !ok) throw new HttpError(401, 'Incorrect email or password.');
    startSession(req, res, user.id);
    return json(res, 200, { user: publicUser(user) });
  }

  if (m === 'POST' && p === '/api/logout') {
    const token = cookies(req).sid;
    if (token) q.deleteSession.run(sha(token));
    clearCookie(req, res);
    return json(res, 200, { ok: true });
  }

  const user = currentUser(req);
  if (!user) throw new HttpError(401, 'Not signed in');

  if (m === 'GET' && p === '/api/me') return json(res, 200, { user: publicUser(user) });
  if (m === 'GET' && p === '/api/tiles/status') return json(res, 200, { ...tileStatus(), roads: roadsStatus() });

  if (m === 'GET' && p === '/api/saved') return json(res, 200, { saved: q.savedList.all(user.id) });

  if (m === 'POST' && p === '/api/saved') {
    const b = await readJson(req);
    const name = typeof b.name === 'string' ? b.name.trim() : '';
    const note = typeof b.note === 'string' ? b.note.trim() : '';
    const { lat, lng } = b;
    if (!name || name.length > 80) throw new HttpError(400, 'Name is required (up to 80 characters).');
    if (note.length > 300) throw new HttpError(400, 'Note is too long (300 characters max).');
    if (typeof lat !== 'number' || typeof lng !== 'number' || !Number.isFinite(lat) || !Number.isFinite(lng) ||
        lat < -90 || lat > 90 || lng < -180 || lng > 180) throw new HttpError(400, 'Invalid coordinates.');
    if (q.savedCount.get(user.id).c >= MAX_SAVED_PER_USER) throw new HttpError(400, `You can save up to ${MAX_SAVED_PER_USER} places.`);
    const created = Date.now();
    const id = Number(q.savedInsert.run(user.id, name, lat, lng, note, created).lastInsertRowid);
    return json(res, 201, { saved: { id, name, lat, lng, note, created_at: created } });
  }

  let mt = /^\/api\/saved\/(\d{1,12})$/.exec(p);
  if (m === 'DELETE' && mt) {
    q.savedDelete.run(Number(mt[1]), user.id);
    return json(res, 200, { ok: true });
  }

  if (p.startsWith('/api/admin/')) {
    if (user.role !== 'admin') throw new HttpError(403, 'Administrators only');
    if (m === 'GET' && p === '/api/admin/users') return json(res, 200, { users: q.adminUsers.all() });
    mt = /^\/api\/admin\/users\/(\d{1,12})$/.exec(p);
    if (m === 'DELETE' && mt) {
      const id = Number(mt[1]);
      if (id === user.id) throw new HttpError(400, 'You cannot delete your own account.');
      q.userDelete.run(id);
      return json(res, 200, { ok: true });
    }
  }

  throw new HttpError(404, 'Not found');
}

/* --------------------------------------------------------------- Tiles */
function tilesRoute(req, res, p) {
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, { Allow: 'GET, HEAD' }); return res.end(); }
  if (!currentUser(req)) return json(res, 401, { error: 'Not signed in' });
  const m = /^\/tiles\/(\d{1,2})\/(\d{1,8})\/(\d{1,8})(?:\.(?:png|jpe?g|webp))?$/.exec(p);
  if (!m) { res.writeHead(404); return res.end(); }
  const z = Number(m[1]), x = Number(m[2]), y = Number(m[3]);
  const n = 2 ** z;
  if (z > 22 || x >= n || y >= n) { res.writeHead(404); return res.end(); }
  const t = getTile(z, x, y);
  if (!t || t.type === 'vector' || t.type === 'application/octet-stream') {
    res.writeHead(404, { 'Cache-Control': 'no-store' });
    return res.end();
  }
  res.writeHead(200, { 'Content-Type': t.type, 'Content-Length': t.data.length, 'Cache-Control': 'private, max-age=604800' });
  res.end(req.method === 'HEAD' ? undefined : t.data);
}

/* -------------------------------------------------------------- Static */
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.webmanifest': 'application/manifest+json', '.ico': 'image/x-icon',
};

function serveStatic(req, res, p) {
  let rel;
  try { rel = decodeURIComponent(p); } catch { res.writeHead(400); return res.end(); }
  if (rel.includes('\0')) { res.writeHead(400); return res.end(); }
  if (rel.endsWith('/')) rel += 'index.html';
  const file = path.join(PUBLIC_DIR, path.normalize(rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) { res.writeHead(404); return res.end(); }
  let st;
  try { st = fs.statSync(file); } catch { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
  if (!st.isFile()) { res.writeHead(404); return res.end(); }
  const etag = `W/"${st.size}-${Math.floor(st.mtimeMs)}"`;
  if (req.headers['if-none-match'] === etag) { res.writeHead(304, { ETag: etag }); return res.end(); }
  const headers = {
    'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
    'Content-Length': st.size,
    ETag: etag,
    'Cache-Control': 'no-cache',
  };
  if (path.basename(file) === 'sw.js') headers['Service-Worker-Allowed'] = '/';
  res.writeHead(200, headers);
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}

/* -------------------------------------------------------------- Server */
const server = http.createServer(async (req, res) => {
  try {
    setSecurityHeaders(res);
    const p = new URL(req.url, 'http://localhost').pathname;
    if (p.startsWith('/api/')) return await api(req, res, p);
    if (p.startsWith('/tiles/')) return tilesRoute(req, res, p);
    if (p === '/roads/graph.json') return roadsRoute(req, res);
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, { Allow: 'GET, HEAD' }); return res.end(); }
    return serveStatic(req, res, p);
  } catch (e) {
    if (res.headersSent) return res.end();
    if (e instanceof HttpError) return json(res, e.status, { error: e.message });
    console.error(e);
    return json(res, 500, { error: 'Server error' });
  }
});

server.listen(PORT, HOST, () => {
  const ts = tileStatus();
  console.log(`\nRaah is running on port ${PORT}`);
  console.log(`  Local:    http://localhost:${PORT}`);
  for (const list of Object.values(os.networkInterfaces())) {
    for (const a of list || []) if (a.family === 'IPv4' && !a.internal) console.log(`  Network:  http://${a.address}:${PORT}`);
  }
  console.log(ts.installed
    ? `  Map tiles: ${ts.name} (${ts.mode}, zoom ${ts.minzoom}-${ts.maxzoom}${ts.vector ? ', VECTOR - not supported yet' : ''})`
    : '  Map tiles: none installed yet. Put a raster .mbtiles file in data/ (see README.md).');
  const rs = roadsStatus();
  console.log(rs.installed ? `  Road data: installed (${(rs.sizeBytes / 1048576).toFixed(1)} MB) - turn-by-turn routing enabled`
    : '  Road data: none (navigation shows a straight line). Build data/roads.json.gz with tools/build-graph.js - see README.md.');
  console.log(`  Registration: ${ALLOW_REGISTRATION ? 'open' : 'closed (after first admin)'}\n`);
});

function shutdown() { server.close(() => { try { db.close(); } catch { /* ignore */ } process.exit(0); }); setTimeout(() => process.exit(0), 3000).unref(); }
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
