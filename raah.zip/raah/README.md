# Raah - offline maps for Dubai (web version)

Login, dashboard, place search, map, navigation and offline downloads. No external dependencies: just Node.js 22.12+.

## Run it

```bash
cd raah
node server.js            # http://localhost:3000
```

The first account you create becomes the **administrator**.

Settings (environment variables):

| Variable | Default | Meaning |
|---|---|---|
| `PORT` | 3000 | Port |
| `ALLOW_REGISTRATION` | on | `0` = only the admin can have accounts (after the first sign-up) |
| `DATA_DIR` | `./data` | Database + map tiles live here |
| `MBTILES` | first `*.mbtiles` in data/ | Path to a map file |
| `COOKIE_SECURE` / `TRUST_PROXY` | off | Set both to `1` behind an HTTPS reverse proxy |

## Add the Dubai map (required for a visible map)

The app serves **raster tiles (PNG/JPG/WebP)** from an MBTiles file.

1. Get a raster MBTiles file for the UAE/Dubai (a tile provider that allows offline use, or render your own from OpenStreetMap data with a tool such as TileMill/Maputnik-style renderers or `tilemaker` + a raster style).
   **Check the licence.** Do not bulk-download tiles from openstreetmap.org's public servers; their policy forbids it.
2. Copy it to `data/` (e.g. `data/dubai.mbtiles`) and restart.
3. The Dashboard "Map data" card should say **Ready**.

Vector MBTiles (`.pbf`) are detected but **not drawn yet** (planned for the app version).
Alternatively, put tiles in `data/tiles/{z}/{x}/{y}.png`.

## Turn-by-turn routing (offline)

Raah routes on **OpenStreetMap** road data, with a router that runs inside the app, so directions work with no internet:
drive-time routing that respects one-way streets, turn instructions with street names, ETA, a route line on the map, and automatic re-routing when you leave the route.

Google Maps data cannot be used for this: Google's terms do not allow copying its map tiles or routes for offline use or for hosting to other people, and its routing API needs internet and is billed per request. OpenStreetMap data (ODbL licence) can be stored and shared if you credit it - the app shows the credit on the Offline page and in the map corner.

**One-time setup (needs internet, on your computer or server):**

1. Download an OSM extract that covers Dubai, for example **BBBike** (extract.bbbike.org, choose your own area, format *OSM XML*) or **Geofabrik** `gcc-states-latest.osm.pbf` (UAE is inside it).
2. If it is a `.pbf`, convert to XML (install `osmium-tool`), keeping only roads and the Dubai area:
   ```bash
   osmium extract -b 54.85,24.70,55.75,25.45 gcc-states-latest.osm.pbf -o dubai.osm.pbf
   osmium tags-filter dubai.osm.pbf w/highway -o roads.osm.pbf
   osmium cat roads.osm.pbf -o dubai.osm
   ```
3. Build the graph (no dependencies, Node only):
   ```bash
   node tools/build-graph.js dubai.osm data/roads.json.gz
   ```
4. Restart the server. The start-up message says *Road data: installed*, and the Dashboard shows **Road routing: Ready**.
5. On each phone: **Offline -> Download road data** (one time, a few MB to tens of MB).

Notes: only drivable roads are used (not footpaths); speeds come from the road type or `maxspeed`; there is no live traffic; roundabouts are described as ordinary turns. The routes are as good as the OpenStreetMap data, so spot-check a few real trips before relying on them.

## How offline works

- First visit (online): sign in. The app files and the Dubai places list are saved on the device by a service worker.
- **Offline** page: choose an area and detail level, press **Download area**. Tiles are stored on the device (about 18 KB each, estimate shown first).
- After that the app opens, searches, shows the map, uses GPS and navigates with no internet. Saved places made offline sync later.
- Phones need **HTTPS** for offline storage and GPS (except `localhost`). Host it behind HTTPS (e.g. Caddy or nginx with a certificate) before sharing with others.

## Hosting for other people

Run it on a small server or VPS, put HTTPS in front, and share the link. Each person creates an account, downloads their area once, and then can use it offline. Use `ALLOW_REGISTRATION=0` to control who joins; the admin can remove users on the Admin page.

## What it does not do yet

- **Walking and cycling routes** (routing is for cars), live traffic, lane guidance, spoken directions.
- Without road data installed, navigation falls back to a straight line with distance and direction.
- Vector tiles, and address search for every street (only the starter list of ~59 places in `public/data/places.json`; coordinates are approximate - verify and extend it).

## Files

- `server.js` - server, auth, API, tiles, road data
- `tools/build-graph.js` - converts OSM XML into the offline road graph
- `public/router.js` - the offline router (A*, one-way streets, turn instructions)
- `public/` - the web app (`app.js`, `map.js` map engine, `sw.js` offline, `places.json` data)
